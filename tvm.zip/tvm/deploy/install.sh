#!/usr/bin/env bash
# TVM Panel installer for Ubuntu 22.04 / 24.04.  Run as root from the unpacked project:
#     sudo bash deploy/install.sh [server_name]
set -euo pipefail

[[ $EUID -eq 0 ]] || { echo "Run as root (sudo)."; exit 1; }
SERVER_NAME="${1:-_}"
SRC="$(cd "$(dirname "$0")/.." && pwd)"
APP=/opt/tvm-panel
WEB=/var/www/tvm-panel
DATA=/var/lib/tvm

echo "==> Installing system packages"
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y qemu-kvm libvirt-daemon-system libvirt-clients libvirt-dev qemu-utils cloud-image-utils \
  python3 python3-venv python3-dev build-essential pkg-config postgresql nginx curl rsync openssl ca-certificates

if ! command -v node >/dev/null || [[ "$(node -v | cut -d. -f1 | tr -d v)" -lt 18 ]]; then
  echo "==> Installing Node.js 20"
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  apt-get install -y nodejs
fi

[[ -e /dev/kvm ]] || echo "WARNING: /dev/kvm not found. Enable VT-x/AMD-V (or nested virtualization on your VPS) or VMs will not start."
systemctl enable --now libvirtd || systemctl enable --now libvirtd.socket || true
virsh net-autostart default >/dev/null 2>&1 || true
virsh net-start default >/dev/null 2>&1 || true

echo "==> Creating service user and directories"
id tvm >/dev/null 2>&1 || useradd --system --home "$APP" --shell /usr/sbin/nologin tvm
usermod -aG libvirt,kvm tvm
mkdir -p "$APP" "$WEB" "$DATA/disks" "$DATA/images"
chown tvm:kvm "$DATA/disks"; chmod 775 "$DATA/disks"
chmod 755 "$DATA" "$DATA/images"

echo "==> Copying application"
rsync -a --delete --exclude venv --exclude .env --exclude node_modules --exclude dist "$SRC/backend/" "$APP/backend/"
rsync -a --delete --exclude node_modules --exclude dist "$SRC/frontend/" "$APP/frontend/"
mkdir -p "$APP/scripts" && rsync -a "$SRC/scripts/" "$APP/scripts/"

echo "==> Configuring PostgreSQL"
ENV_FILE="$APP/backend/.env"
if [[ -f "$ENV_FILE" ]]; then
  echo "    Existing .env kept."
  DB_URL="$(grep '^DATABASE_URL=' "$ENV_FILE" | cut -d= -f2-)"
else
  DB_PASS="$(openssl rand -hex 24)"
  sudo -u postgres psql -v ON_ERROR_STOP=1 <<SQL
DO \$\$ BEGIN
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'tvm') THEN CREATE ROLE tvm LOGIN PASSWORD '$DB_PASS';
  ELSE ALTER ROLE tvm PASSWORD '$DB_PASS'; END IF;
END \$\$;
SQL
  sudo -u postgres psql -tc "SELECT 1 FROM pg_database WHERE datname='tvm'" | grep -q 1 || sudo -u postgres createdb -O tvm tvm
  DB_URL="postgresql+psycopg://tvm:${DB_PASS}@127.0.0.1:5432/tvm"
  cat > "$ENV_FILE" <<EOF
DATABASE_URL=$DB_URL
SECRET_KEY=$(openssl rand -hex 32)
LIBVIRT_URI=qemu:///system
STORAGE_DIR=$DATA/disks
LIBVIRT_NETWORK=default
LIBVIRT_BRIDGE=
SESSION_HOURS=168
# Change to true after enabling HTTPS (see README), otherwise logins over plain HTTP will not stick.
COOKIE_SECURE=false
EOF
fi
chown -R tvm:tvm "$APP"; chmod 600 "$ENV_FILE"

echo "==> Applying database schema"
PSQL_URL="${DB_URL/postgresql+psycopg/postgresql}"
psql "$PSQL_URL" -v ON_ERROR_STOP=1 -f "$APP/backend/schema.sql"

echo "==> Python environment"
sudo -u tvm python3 -m venv "$APP/backend/venv"
sudo -u tvm "$APP/backend/venv/bin/pip" install --upgrade pip
sudo -u tvm "$APP/backend/venv/bin/pip" install -r "$APP/backend/requirements.txt"

echo "==> Building frontend"
( cd "$APP/frontend" && sudo -u tvm npm install --no-audit --no-fund && sudo -u tvm npm run build )
rsync -a --delete "$APP/frontend/dist/" "$WEB/"

echo "==> systemd service"
install -m 644 "$SRC/deploy/tvm-panel.service" /etc/systemd/system/tvm-panel.service
systemctl daemon-reload
systemctl enable --now tvm-panel

echo "==> nginx"
sed "s/__SERVER_NAME__/$SERVER_NAME/" "$SRC/deploy/nginx.conf" > /etc/nginx/sites-available/tvm-panel
ln -sf /etc/nginx/sites-available/tvm-panel /etc/nginx/sites-enabled/tvm-panel
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl reload nginx

if command -v ufw >/dev/null && ufw status | grep -q "Status: active"; then ufw allow 'Nginx Full' || true; fi

cat <<MSG

TVM Panel is installed.

Next steps:
  1. Create the first administrator:
       cd $APP/backend && sudo -u tvm venv/bin/python -m app.cli create-admin
  2. Add an OS template (downloads Ubuntu 24.04 cloud image):  sudo bash $APP/scripts/download_images.sh
  3. Open http://${SERVER_NAME/_/<server-ip>}/ and sign in.
  4. Enable HTTPS (certbot), then set COOKIE_SECURE=true in $ENV_FILE and: systemctl restart tvm-panel
MSG
