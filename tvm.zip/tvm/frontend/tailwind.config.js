/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        bg: "#09090c",
        panel: "#111116",
        panel2: "#16161c",
        line: "#23232b",
        muted: "#8b8b98",
        accent: "rgb(var(--accent) / <alpha-value>)",
      },
      fontFamily: { sans: ["Inter", "ui-sans-serif", "system-ui", "sans-serif"] },
      boxShadow: { glow: "0 0 24px -8px rgb(var(--accent) / 0.45)" },
    },
  },
  plugins: [],
};
