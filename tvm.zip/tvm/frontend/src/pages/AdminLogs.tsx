import { useEffect, useState } from "react";
import { FileText, Search } from "lucide-react";
import { api, fmtDate, qs } from "../api";
import type { Activity, Page } from "../types";
import { Badge, Card, Column, DataTable, EmptyState, ErrorState, PageHeader, Pagination, useDebounced, useLoad } from "../components/ui";

export default function AdminLogs() {
  const [search, setSearch] = useState("");
  const [level, setLevel] = useState("");
  const [page, setPage] = useState(1);
  const q = useDebounced(search);
  useEffect(() => setPage(1), [q, level]);
  const list = useLoad(() => api<Page<Activity>>(`/admin/logs${qs({ search: q, level, page, page_size: 20 })}`), [q, level, page], 15);

  const cols: Column<Activity>[] = [
    { key: "t", header: "Time", render: (a) => <span className="whitespace-nowrap text-muted">{fmtDate(a.created_at)}</span> },
    { key: "u", header: "User", render: (a) => a.user ?? <span className="text-muted">system</span> },
    { key: "a", header: "Action", render: (a) => <Badge tone={a.level === "error" ? "red" : a.level === "warning" ? "amber" : "blue"}>{a.action}</Badge> },
    { key: "d", header: "Details", render: (a) => <span className="text-zinc-300">{a.detail}</span> },
    { key: "i", header: "IP", render: (a) => <span className="font-mono text-xs text-muted">{a.ip ?? "—"}</span> },
  ];

  return (
    <>
      <PageHeader title="Activity Logs" subtitle="Audit trail of logins, VM operations and admin changes" />
      <Card>
        <div className="flex flex-wrap gap-2 border-b border-line p-3">
          <div className="relative min-w-[200px] max-w-sm flex-1"><Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted" /><input className="input pl-8" placeholder="Search logs…" value={search} onChange={(e) => setSearch(e.target.value)} /></div>
          <select className="input !w-auto" value={level} onChange={(e) => setLevel(e.target.value)} aria-label="Level"><option value="">All levels</option><option value="info">Info</option><option value="warning">Warning</option><option value="error">Error</option></select>
        </div>
        {list.error && <ErrorState message={list.error} onRetry={list.reloadFull} />}
        <DataTable columns={cols} rows={list.data?.items ?? []} loading={list.loading && !list.data} rowKey={(a) => a.id} skeletonRows={8} empty={<EmptyState icon={<FileText size={22} />} title="No log entries" />} />
        <Pagination page={page} pageSize={20} total={list.data?.total ?? 0} onPage={setPage} />
      </Card>
    </>
  );
}
