import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { CheckCircle2, Cpu, HardDrive, Play, Plus, RefreshCw, Server, Settings, Square, Users, XCircle } from "lucide-react";
import clsx from "clsx";
import { api, fmtRam, timeAgo } from "../api";
import type { Activity, Page, SystemStatus } from "../types";
import { Badge, Card, CardHeader, EmptyState, ErrorState, PageHeader, ProgressBar, Skeleton, StatCard, loadTone, useLoad } from "../components/ui";

interface Stats { total_vms: number; running_vms: number; stopped_vms: number; users: number; templates: number }
const INTERVALS = [[0, "Off"], [5, "5s"], [10, "10s"], [30, "30s"], [60, "60s"]] as const;

export default function AdminDashboard() {
  const [auto, setAuto] = useState<number>(() => Number(localStorage.getItem("tvm_admin_refresh") ?? 10));
  useEffect(() => {
    // Apply the admin-configured default unless this browser has its own choice.
    if (localStorage.getItem("tvm_admin_refresh") === null)
      api<{ refresh_interval_seconds: number }>("/public-config").then((c) => setAuto(c.refresh_interval_seconds)).catch(() => {});
  }, []);
  const stats = useLoad(() => api<Stats>("/admin/stats"), [], auto);
  const sys = useLoad(() => api<SystemStatus>("/admin/system-status"), [], auto);
  const logs = useLoad(() => api<Page<Activity>>("/admin/logs?page_size=8"), [], auto);
  const reload = () => { stats.reload(); sys.reload(); logs.reload(); };
  const live = auto > 0 && !stats.error;

  const quick = [
    { to: "/admin/vms/new", label: "Create VM", sub: "Provision a new guest", icon: <Plus size={18} />, cls: "text-violet-300 border-violet-500/25 bg-violet-500/10" },
    { to: "/admin/users", label: "Manage Users", sub: "Roles, quotas, access", icon: <Users size={18} />, cls: "text-blue-300 border-blue-500/25 bg-blue-500/10" },
    { to: "/admin/templates", label: "OS Templates", sub: "Images and ISOs", icon: <HardDrive size={18} />, cls: "text-cyan-300 border-cyan-500/25 bg-cyan-500/10" },
    { to: "/admin/settings", label: "Settings", sub: "Limits and registration", icon: <Settings size={18} />, cls: "text-emerald-300 border-emerald-500/25 bg-emerald-500/10" },
  ];
  const h = sys.data?.host;

  return (
    <>
      <PageHeader title="Admin Dashboard" subtitle="Host and platform overview"
        actions={<>
          <span className="flex items-center gap-1.5 text-xs text-muted"><span className={clsx("h-2 w-2 rounded-full", live ? "bg-emerald-400 live-dot" : "bg-zinc-600")} />{live ? "Live" : "Paused"}</span>
          <select className="input !w-auto !py-1.5" value={auto} aria-label="Auto refresh interval" onChange={(e) => { const n = Number(e.target.value); setAuto(n); localStorage.setItem("tvm_admin_refresh", String(n)); }}>
            {INTERVALS.map(([v, l]) => <option key={v} value={v}>Auto refresh: {l}</option>)}
          </select>
          <button className="btn" onClick={reload}><RefreshCw size={14} /> Refresh</button>
          <Link to="/admin/vms/new" className="btn btn-primary"><Plus size={15} /> New VM</Link>
        </>} />

      {stats.error && <Card className="mb-4"><ErrorState message={stats.error} onRetry={stats.reloadFull} /></Card>}
      <div className="mb-4 grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label="Total VMs" value={stats.data?.total_vms ?? 0} icon={<Server size={18} />} tone="purple" loading={stats.loading && !stats.data} />
        <StatCard label="Running VMs" value={stats.data?.running_vms ?? 0} icon={<Play size={18} />} tone="green" loading={stats.loading && !stats.data} />
        <StatCard label="Stopped VMs" value={stats.data?.stopped_vms ?? 0} icon={<Square size={18} />} tone="red" loading={stats.loading && !stats.data} />
        <StatCard label="Registered Users" value={stats.data?.users ?? 0} icon={<Users size={18} />} tone="blue" loading={stats.loading && !stats.data} />
      </div>

      <div className="mb-4 grid grid-cols-2 gap-3 lg:grid-cols-4">
        {quick.map((q) => (
          <Link key={q.to} to={q.to} className="card group flex items-center gap-3 p-3.5 transition hover:border-zinc-600 hover:shadow-glow">
            <span className={clsx("flex h-10 w-10 items-center justify-center rounded-lg border", q.cls)}>{q.icon}</span>
            <span><span className="block font-medium text-zinc-100 group-hover:text-accent">{q.label}</span><span className="text-[11px] text-muted">{q.sub}</span></span>
          </Link>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-5">
        <Card className="lg:col-span-3">
          <CardHeader title="Recent activity" icon={<Cpu size={15} className="text-accent" />} actions={<Link to="/admin/logs" className="text-xs text-accent hover:underline">View all</Link>} />
          {logs.error && <ErrorState message={logs.error} onRetry={logs.reloadFull} />}
          {logs.loading && !logs.data && <div className="space-y-3 p-4">{[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-5 w-full" />)}</div>}
          {logs.data?.items.length === 0 && <EmptyState title="No activity yet" />}
          <ul className="divide-y divide-line">
            {logs.data?.items.map((a) => (
              <li key={a.id} className="flex items-start justify-between gap-3 px-4 py-2.5">
                <div className="min-w-0"><p className="text-[13px] text-zinc-200">{a.detail || a.action}</p><p className="text-[11px] text-muted">{a.user ?? "system"}{a.ip ? ` · ${a.ip}` : ""}</p></div>
                <div className="flex shrink-0 flex-col items-end gap-1"><Badge tone={a.level === "error" ? "red" : a.level === "warning" ? "amber" : "blue"}>{a.action}</Badge><span className="text-[11px] text-muted">{timeAgo(a.created_at)}</span></div>
              </li>
            ))}
          </ul>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader title="System status" icon={<Server size={15} className="text-cyan-300" />} />
          {sys.error && <ErrorState message={sys.error} onRetry={sys.reloadFull} />}
          {sys.loading && !sys.data && <div className="space-y-3 p-4">{[0, 1, 2, 3, 4].map((i) => <Skeleton key={i} className="h-5 w-full" />)}</div>}
          {sys.data && h && (
            <div className="space-y-4 p-4">
              {([["KVM", sys.data.kvm], ["libvirt / QEMU", sys.data.libvirt], ["Database", sys.data.database]] as const).map(([name, s]) => (
                <div key={name} className="flex items-start gap-2.5">
                  {s.ok ? <CheckCircle2 size={16} className="mt-0.5 text-emerald-400" /> : <XCircle size={16} className="mt-0.5 text-red-400" />}
                  <div><p className="text-[13px] font-medium text-zinc-100">{name}</p><p className="text-[11px] text-muted">{s.detail}</p></div>
                </div>
              ))}
              <div className="space-y-3 border-t border-line pt-4">
                {([["CPU", h.cpu_percent, `${h.cpu_percent}% · ${h.cpu_count} cores`], ["Memory", h.mem_percent, `${fmtRam(h.mem_used_mb)} / ${fmtRam(h.mem_total_mb)}`], ["Disk", h.disk_percent, `${h.disk_used_gb} / ${h.disk_total_gb} GB`]] as const).map(([k, p, t]) => (
                  <div key={k}><div className="mb-1 flex justify-between text-xs"><span className="text-muted">{k}</span><span className="text-zinc-200">{t}</span></div><ProgressBar value={p} tone={loadTone(p)} /></div>
                ))}
                <p className="text-[11px] text-muted">Load average: {h.load.join(" / ")}</p>
              </div>
            </div>
          )}
        </Card>
      </div>
    </>
  );
}
