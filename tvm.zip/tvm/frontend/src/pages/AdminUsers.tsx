import { FormEvent, useEffect, useState } from "react";
import { Pencil, Plus, Search, Trash2, Users as UsersIcon } from "lucide-react";
import { api, fmtDate, qs } from "../api";
import { errText, useAuth, useToast } from "../context";
import type { Page, User } from "../types";
import { Badge, Card, Column, ConfirmDialog, DataTable, EmptyState, ErrorState, Field, Modal, PageHeader, Pagination, Spinner, Toggle, useDebounced, useLoad } from "../components/ui";

export default function AdminUsers() {
  const { user: me } = useAuth();
  const toast = useToast();
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const q = useDebounced(search);
  useEffect(() => setPage(1), [q]);
  const list = useLoad(() => api<Page<User>>(`/admin/users${qs({ search: q, page, page_size: 10 })}`), [q, page], 20);
  const [edit, setEdit] = useState<User | null>(null);
  const [creating, setCreating] = useState(false);
  const [del, setDel] = useState<User | null>(null);

  const cols: Column<User>[] = [
    { key: "u", header: "User", render: (u) => <div><p className="font-medium text-zinc-100">{u.username}</p><p className="text-[11px] text-muted">{u.email}</p></div> },
    { key: "r", header: "Role", render: (u) => <Badge tone={u.role === "admin" ? "purple" : "gray"}>{u.role}</Badge> },
    { key: "s", header: "Status", render: (u) => <Badge tone={u.is_active ? "green" : "red"}>{u.is_active ? "Active" : "Disabled"}</Badge> },
    { key: "v", header: "VMs", render: (u) => `${u.vm_count}${u.max_vms !== null ? ` / ${u.max_vms}` : ""}` },
    { key: "l", header: "Last sign-in", render: (u) => <span className="text-muted">{fmtDate(u.last_login)}</span> },
    { key: "a", header: "Actions", className: "text-right", render: (u) => (
      <div className="flex justify-end gap-0.5">
        <button className="btn-icon" title="Edit" onClick={() => setEdit(u)}><Pencil size={15} /></button>
        <button className="btn-icon hover:!text-red-400" title="Delete" disabled={u.id === me?.id} onClick={() => setDel(u)}><Trash2 size={15} /></button>
      </div>) },
  ];

  return (
    <>
      <PageHeader title="Users" subtitle="Manage accounts, roles and quotas" actions={<button className="btn btn-primary" onClick={() => setCreating(true)}><Plus size={15} /> New user</button>} />
      <Card>
        <div className="border-b border-line p-3"><div className="relative max-w-sm"><Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted" /><input className="input pl-8" placeholder="Search users…" value={search} onChange={(e) => setSearch(e.target.value)} /></div></div>
        {list.error && <ErrorState message={list.error} onRetry={list.reloadFull} />}
        <DataTable columns={cols} rows={list.data?.items ?? []} loading={list.loading && !list.data} rowKey={(u) => u.id} empty={<EmptyState icon={<UsersIcon size={22} />} title="No users found" />} />
        <Pagination page={page} pageSize={10} total={list.data?.total ?? 0} onPage={setPage} />
      </Card>
      {edit && <EditUser user={edit} self={edit.id === me?.id} onClose={() => setEdit(null)} onSaved={() => { setEdit(null); list.reload(); }} />}
      {creating && <CreateUser onClose={() => setCreating(false)} onSaved={() => { setCreating(false); list.reload(); }} />}
      <ConfirmDialog open={!!del} danger title="Delete user" confirmLabel="Delete user" onClose={() => setDel(null)}
        message={<>Delete <b>{del?.username}</b>? Their {del?.vm_count ?? 0} VM(s) and disks will be permanently destroyed.</>}
        onConfirm={async () => { try { await api(`/admin/users/${del!.id}`, { method: "DELETE" }); toast.push("success", "User deleted"); list.reload(); } catch (e) { toast.push("error", errText(e)); } }} />
    </>
  );
}

function EditUser({ user, self, onClose, onSaved }: { user: User; self: boolean; onClose: () => void; onSaved: () => void }) {
  const toast = useToast();
  const [role, setRole] = useState(user.role);
  const [active, setActive] = useState(user.is_active);
  const [max, setMax] = useState(user.max_vms === null ? "" : String(user.max_vms));
  const [pw, setPw] = useState("");
  const [busy, setBusy] = useState(false);
  const save = async (e: FormEvent) => {
    e.preventDefault(); setBusy(true);
    try {
      await api(`/admin/users/${user.id}`, { method: "PATCH", body: { role, is_active: active, max_vms: max === "" ? undefined : Number(max), clear_max_vms: max === "", new_password: pw || undefined } });
      toast.push("success", "User updated"); onSaved();
    } catch (e2) { toast.push("error", errText(e2)); setBusy(false); }
  };
  return (
    <Modal open onClose={onClose} title={`Edit ${user.username}`} footer={<><button className="btn" onClick={onClose}>Cancel</button><button className="btn btn-primary" form="edit-user" disabled={busy}>{busy && <Spinner />}Save</button></>}>
      <form id="edit-user" onSubmit={save} className="space-y-4">
        <Field label="Role"><select className="input" value={role} disabled={self} onChange={(e) => setRole(e.target.value as User["role"])}><option value="user">User</option><option value="admin">Administrator</option></select></Field>
        <Field label="VM quota" hint="Leave empty to use the default from Settings"><input type="number" min={0} className="input" value={max} onChange={(e) => setMax(e.target.value)} /></Field>
        <Field label="Reset password" hint="Leave empty to keep the current one"><input type="password" className="input" value={pw} onChange={(e) => setPw(e.target.value)} autoComplete="new-password" minLength={8} /></Field>
        <Toggle checked={active} onChange={(v) => !self && setActive(v)} label="Account active" />
      </form>
    </Modal>
  );
}

function CreateUser({ onClose, onSaved }: { onClose: () => void; onSaved: () => void }) {
  const toast = useToast();
  const [f, setF] = useState({ email: "", username: "", password: "", role: "user" });
  const [busy, setBusy] = useState(false);
  const save = async (e: FormEvent) => {
    e.preventDefault(); setBusy(true);
    try { await api("/admin/users", { method: "POST", body: f }); toast.push("success", "User created"); onSaved(); }
    catch (e2) { toast.push("error", errText(e2)); setBusy(false); }
  };
  return (
    <Modal open onClose={onClose} title="New user" footer={<><button className="btn" onClick={onClose}>Cancel</button><button className="btn btn-primary" form="new-user" disabled={busy}>{busy && <Spinner />}Create</button></>}>
      <form id="new-user" onSubmit={save} className="space-y-4">
        <Field label="Email"><input type="email" className="input" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} required /></Field>
        <Field label="Username"><input className="input" value={f.username} onChange={(e) => setF({ ...f, username: e.target.value })} required /></Field>
        <Field label="Password" hint="At least 8 characters"><input type="password" className="input" value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} minLength={8} required autoComplete="new-password" /></Field>
        <Field label="Role"><select className="input" value={f.role} onChange={(e) => setF({ ...f, role: e.target.value })}><option value="user">User</option><option value="admin">Administrator</option></select></Field>
      </form>
    </Modal>
  );
}
