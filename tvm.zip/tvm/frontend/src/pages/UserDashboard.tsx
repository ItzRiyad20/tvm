import { Link } from "react-router-dom";
import { Cpu, MemoryStick, Play, Plus, RefreshCw, Server, Square } from "lucide-react";
import { api, fmtRam, qs, timeAgo } from "../api";
import { useAuth } from "../context";
import type { Activity, Page, Summary, VM } from "../types";
import { Badge, Card, CardHeader, EmptyState, ErrorState, PageHeader, Skeleton, StatCard, StatusBadge, useLoad } from "../components/ui";

export default function UserDashboard() {
  const { user } = useAuth();
  const sum = useLoad(() => api<Summary>("/vms/summary"), [], 10);
  const vms = useLoad(() => api<Page<VM>>(`/vms${qs({ page_size: 5, sort: "created", order: "desc" })}`), [], 10);
  const acts = useLoad(() => api<Activity[]>("/activity?limit=8"), [], 15);

  return (
    <>
      <PageHeader title={`Welcome back, ${user?.username}`} subtitle="Overview of your virtual infrastructure"
        actions={<><button className="btn" onClick={() => { sum.reload(); vms.reload(); acts.reload(); }}><RefreshCw size={14} /> Refresh</button>
          <Link to="/vms/new" className="btn btn-primary"><Plus size={15} /> New VM</Link></>} />
      <div className="mb-4 grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label="Total VMs" value={sum.data?.total ?? 0} icon={<Server size={18} />} tone="purple" loading={sum.loading} />
        <StatCard label="Running" value={sum.data?.running ?? 0} icon={<Play size={18} />} tone="green" loading={sum.loading} />
        <StatCard label="Stopped" value={sum.data?.stopped ?? 0} icon={<Square size={18} />} tone="red" loading={sum.loading} />
        <StatCard label="Total RAM" value={fmtRam(sum.data?.total_ram_mb ?? 0)} icon={<MemoryStick size={18} />} tone="cyan" loading={sum.loading} />
      </div>
      <div className="grid gap-4 lg:grid-cols-5">
        <Card className="lg:col-span-3">
          <CardHeader title="Recent virtual machines" icon={<Cpu size={15} className="text-accent" />} actions={<Link to="/vms" className="text-xs text-accent hover:underline">View all</Link>} />
          {vms.error && <ErrorState message={vms.error} onRetry={vms.reloadFull} />}
          {vms.loading && !vms.data && <div className="space-y-3 p-4">{[0, 1, 2].map((i) => <Skeleton key={i} className="h-8 w-full" />)}</div>}
          {vms.data?.items.length === 0 && <EmptyState title="No virtual machines yet" text="Create your first VM to see it here." action={<Link to="/vms/new" className="btn btn-primary"><Plus size={14} /> Create VM</Link>} />}
          <ul className="divide-y divide-line">
            {vms.data?.items.map((v) => (
              <li key={v.id}><Link to={`/vms/${v.id}`} className="flex items-center justify-between gap-3 px-4 py-3 transition hover:bg-panel2/50">
                <div className="min-w-0"><p className="truncate font-medium text-zinc-100">{v.name}</p><p className="truncate text-xs text-muted">{v.os_name} · {v.cpu} vCPU · {fmtRam(v.ram_mb)} · {v.ip_address ?? "no IP"}</p></div>
                <StatusBadge status={v.status} />
              </Link></li>
            ))}
          </ul>
        </Card>
        <Card className="lg:col-span-2">
          <CardHeader title="Recent activity" />
          {acts.error && <ErrorState message={acts.error} onRetry={acts.reloadFull} />}
          {acts.data?.length === 0 && <EmptyState title="No activity yet" />}
          <ul className="divide-y divide-line">
            {acts.data?.map((a) => (
              <li key={a.id} className="flex items-start justify-between gap-3 px-4 py-2.5">
                <div className="min-w-0"><p className="text-[13px] text-zinc-200">{a.detail || a.action}</p><Badge tone={a.level === "error" ? "red" : a.level === "warning" ? "amber" : "blue"}>{a.action}</Badge></div>
                <span className="shrink-0 text-[11px] text-muted">{timeAgo(a.created_at)}</span>
              </li>
            ))}
          </ul>
        </Card>
      </div>
    </>
  );
}
