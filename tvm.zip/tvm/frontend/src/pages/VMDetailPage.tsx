import { useEffect, useRef, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { ArrowLeft, Clock, Cpu, HardDrive, MemoryStick, Monitor, Network, RefreshCw } from "lucide-react";
import { api, fmtBytes, fmtDate, fmtRam, fmtUptime, timeAgo } from "../api";
import type { Activity, Metrics, VM } from "../types";
import { VMActions } from "../components/VMParts";
import { Badge, Card, CardHeader, EmptyState, ErrorState, ProgressBar, Skeleton, Sparkline, StatusBadge, loadTone, useLoad } from "../components/ui";

export default function VMDetailPage({ admin }: { admin?: boolean }) {
  const { id } = useParams();
  const nav = useNavigate();
  const base = admin ? "/admin" : "";
  const vm = useLoad(() => api<VM>(`/vms/${id}`), [id], 10);
  const logs = useLoad(() => api<Activity[]>(`/vms/${id}/logs?limit=20`), [id], 15);
  const [m, setM] = useState<Metrics | null>(null);
  const [metricsErr, setMetricsErr] = useState<string | null>(null);
  const [cpuHist, setCpuHist] = useState<number[]>([]);
  const [memHist, setMemHist] = useState<number[]>([]);
  const prevNet = useRef<{ t: number; rx: number; tx: number } | null>(null);
  const [rate, setRate] = useState({ rx: 0, tx: 0 });

  useEffect(() => {
    setCpuHist([]); setMemHist([]); prevNet.current = null;
    let stop = false;
    const tick = async () => {
      if (document.hidden) return;
      try {
        const x = await api<Metrics>(`/vms/${id}/metrics`);
        if (stop) return;
        setM(x); setMetricsErr(null);
        setCpuHist((h) => [...h, x.cpu_percent].slice(-40));
        setMemHist((h) => [...h, x.mem_total_mb ? (x.mem_used_mb / x.mem_total_mb) * 100 : 0].slice(-40));
        const now = Date.now(), p = prevNet.current;
        if (p && now > p.t) setRate({ rx: Math.max(0, ((x.net_rx_bytes - p.rx) / (now - p.t)) * 1000), tx: Math.max(0, ((x.net_tx_bytes - p.tx) / (now - p.t)) * 1000) });
        prevNet.current = { t: now, rx: x.net_rx_bytes, tx: x.net_tx_bytes };
      } catch (e) { if (!stop) setMetricsErr(e instanceof Error ? e.message : "Metrics unavailable"); }
    };
    tick();
    const t = setInterval(tick, 3000);
    return () => { stop = true; clearInterval(t); };
  }, [id]);

  const refresh = () => { vm.reload(); logs.reload(); };
  const v = vm.data;
  const running = v?.status === "running";
  const memPct = m && m.mem_total_mb ? (m.mem_used_mb / m.mem_total_mb) * 100 : 0;
  const diskPct = m && m.disk_total_gb ? (m.disk_used_gb / m.disk_total_gb) * 100 : 0;

  if (vm.error && !v) return <><Link to={`${base}/vms`} className="btn mb-4"><ArrowLeft size={14} /> Back</Link><Card><ErrorState message={vm.error} onRetry={vm.reloadFull} /></Card></>;

  return (
    <>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <Link to={`${base}/vms`} className="btn-icon border-line" aria-label="Back"><ArrowLeft size={16} /></Link>
          <div>
            {v ? <h1 className="flex items-center gap-2.5 text-lg font-semibold text-zinc-50">{v.name} <StatusBadge status={v.status} /></h1> : <Skeleton className="h-6 w-48" />}
            <p className="text-xs text-muted">{v ? `#${v.id} · ${v.os_name}${admin && v.owner_name ? ` · owner ${v.owner_name}` : ""}` : ""}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button className="btn" onClick={refresh}><RefreshCw size={14} /> Refresh</button>
          {running && <button className="btn btn-primary" onClick={() => nav(`${base}/vms/${id}/console`)}><Monitor size={14} /> Console</button>}
          {v && <div className="rounded-lg border border-line bg-panel2 px-1.5 py-0.5"><VMActions vm={v} base={base} onDone={() => { if (!document.hidden) { refresh(); } }} /></div>}
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader title="Resource usage" icon={<Cpu size={15} className="text-accent" />} actions={running ? <Badge tone="green">Live · 3s</Badge> : <Badge>Not running</Badge>} />
          {metricsErr && <ErrorState message={metricsErr} />}
          <div className="grid gap-4 p-4 sm:grid-cols-2">
            <div className="rounded-lg border border-line bg-panel2/50 p-3">
              <div className="mb-1 flex justify-between text-xs"><span className="flex items-center gap-1.5 text-muted"><Cpu size={13} /> CPU</span><span className="font-semibold text-zinc-100">{m ? `${m.cpu_percent}%` : "—"}</span></div>
              <Sparkline data={cpuHist} color="#a78bfa" />
            </div>
            <div className="rounded-lg border border-line bg-panel2/50 p-3">
              <div className="mb-1 flex justify-between text-xs"><span className="flex items-center gap-1.5 text-muted"><MemoryStick size={13} /> Memory</span><span className="font-semibold text-zinc-100">{m ? `${fmtRam(m.mem_used_mb)} / ${fmtRam(m.mem_total_mb)}` : "—"}</span></div>
              <Sparkline data={memHist} color="#22d3ee" />
            </div>
            <div className="rounded-lg border border-line bg-panel2/50 p-3">
              <div className="mb-2 flex justify-between text-xs"><span className="flex items-center gap-1.5 text-muted"><HardDrive size={13} /> Disk (allocated)</span><span className="font-semibold text-zinc-100">{m ? `${m.disk_used_gb} / ${m.disk_total_gb} GB` : "—"}</span></div>
              <ProgressBar value={diskPct} tone={loadTone(diskPct)} />
            </div>
            <div className="rounded-lg border border-line bg-panel2/50 p-3">
              <div className="mb-1 flex justify-between text-xs"><span className="flex items-center gap-1.5 text-muted"><Network size={13} /> Network</span></div>
              <p className="text-[13px] text-zinc-200">↓ {fmtBytes(rate.rx)}/s &nbsp; ↑ {fmtBytes(rate.tx)}/s</p>
              <p className="text-[11px] text-muted">Total ↓ {fmtBytes(m?.net_rx_bytes ?? 0)} · ↑ {fmtBytes(m?.net_tx_bytes ?? 0)}</p>
            </div>
          </div>
          {running && m && m.mem_used_mb === 0 && <p className="px-4 pb-3 text-[11px] text-muted">Memory usage is reported via the virtio balloon driver; it may show 0 until the guest reports statistics.</p>}
          <span className="hidden">{memPct}</span>
        </Card>

        <Card>
          <CardHeader title="System information" icon={<Clock size={15} className="text-cyan-300" />} />
          <dl className="divide-y divide-line text-[13px]">
            {!v ? Array.from({ length: 7 }).map((_, i) => <div key={i} className="p-3"><Skeleton /></div>) : ([
              ["Uptime", running ? fmtUptime(m?.uptime_seconds ?? 0) : "—"], ["Operating system", v.os_name], ["vCPU", `${v.cpu}`], ["Memory", fmtRam(v.ram_mb)], ["Disk", `${v.disk_gb} GB`],
              ["IP address", v.ip_address ?? "—"], ["MAC address", v.mac ?? "—"], ["Network", v.network], ["Created", fmtDate(v.created_at)], ["Started", fmtDate(v.started_at)],
              ...(admin && v.libvirt_name ? [["Libvirt domain", v.libvirt_name]] : []),
            ] as string[][]).map(([k, val]) => <div key={k} className="flex justify-between gap-3 px-4 py-2"><dt className="text-muted">{k}</dt><dd className="break-all text-right font-medium text-zinc-100">{val}</dd></div>)}
          </dl>
        </Card>

        <Card className="lg:col-span-3">
          <CardHeader title="Activity log" />
          {logs.error && <ErrorState message={logs.error} onRetry={logs.reloadFull} />}
          {logs.data?.length === 0 && <EmptyState title="No activity recorded" text="Actions on this VM will show up here." />}
          <ul className="divide-y divide-line">
            {logs.data?.map((a) => (
              <li key={a.id} className="flex items-center justify-between gap-3 px-4 py-2.5">
                <div className="flex items-center gap-2.5"><Badge tone={a.level === "error" ? "red" : a.level === "warning" ? "amber" : "blue"}>{a.action}</Badge><span className="text-[13px] text-zinc-300">{a.detail}</span></div>
                <span className="shrink-0 text-[11px] text-muted" title={fmtDate(a.created_at)}>{timeAgo(a.created_at)}</span>
              </li>
            ))}
          </ul>
        </Card>
      </div>
    </>
  );
}
