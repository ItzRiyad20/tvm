import { FormEvent, useEffect, useState } from "react";
import { Save } from "lucide-react";
import { api } from "../api";
import { errText, useToast } from "../context";
import type { PanelSettings } from "../types";
import { Card, CardHeader, ErrorState, Field, PageHeader, Skeleton, Spinner, Toggle, useLoad } from "../components/ui";

export default function AdminSettings() {
  const toast = useToast();
  const s = useLoad(() => api<PanelSettings>("/admin/settings"), []);
  const [f, setF] = useState<PanelSettings | null>(null);
  const [busy, setBusy] = useState(false);
  useEffect(() => { if (s.data) setF(s.data); }, [s.data]);

  const save = async (e: FormEvent) => {
    e.preventDefault(); if (!f) return; setBusy(true);
    try { await api("/admin/settings", { method: "PUT", body: f }); toast.push("success", "Settings saved"); s.reload(); }
    catch (e2) { toast.push("error", errText(e2)); }
    finally { setBusy(false); }
  };
  const num = (k: keyof PanelSettings) => ({ type: "number", className: "input", value: f ? (f[k] as number) : 0, onChange: (e: React.ChangeEvent<HTMLInputElement>) => setF({ ...f!, [k]: Number(e.target.value) }) });

  return (
    <>
      <PageHeader title="Settings" subtitle="Platform-wide limits and behaviour" />
      {s.error && <Card><ErrorState message={s.error} onRetry={s.reloadFull} /></Card>}
      {!f && !s.error && <Card className="space-y-3 p-4">{[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-9 w-full" />)}</Card>}
      {f && (
        <form onSubmit={save} className="grid gap-4 lg:grid-cols-2">
          <Card>
            <CardHeader title="General" />
            <div className="space-y-4 p-4">
              <Field label="Panel name"><input className="input" value={f.panel_name} onChange={(e) => setF({ ...f, panel_name: e.target.value })} maxLength={64} /></Field>
              <Toggle checked={f.allow_registration} onChange={(v) => setF({ ...f, allow_registration: v })} label="Allow public registration" />
              <Field label="Default dashboard refresh (seconds, 0 = off)"><input min={0} max={3600} {...num("refresh_interval_seconds")} /></Field>
            </div>
          </Card>
          <Card>
            <CardHeader title="Limits for regular users" />
            <div className="grid gap-4 p-4 sm:grid-cols-2">
              <Field label="Default VM quota per user"><input min={0} {...num("default_max_vms")} /></Field>
              <Field label="Max vCPU per VM"><input min={1} {...num("max_cpu_per_vm")} /></Field>
              <Field label="Max RAM per VM (MB)"><input min={256} {...num("max_ram_mb_per_vm")} /></Field>
              <Field label="Max disk per VM (GB)"><input min={1} {...num("max_disk_gb_per_vm")} /></Field>
              <p className="text-[11px] text-muted sm:col-span-2">Administrators are not restricted by these limits.</p>
            </div>
          </Card>
          <div className="lg:col-span-2"><button className="btn btn-primary" disabled={busy}>{busy ? <Spinner /> : <Save size={14} />} Save settings</button></div>
        </form>
      )}
    </>
  );
}
