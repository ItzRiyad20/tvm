import { FormEvent, useState } from "react";
import { HardDrive, Pencil, Plus, Trash2 } from "lucide-react";
import { api } from "../api";
import { errText, useToast } from "../context";
import type { Template } from "../types";
import { Badge, Card, Column, ConfirmDialog, DataTable, EmptyState, ErrorState, Field, Modal, PageHeader, Spinner, Toggle, useLoad } from "../components/ui";

const blank = { name: "", os_family: "linux", version: "", image_path: "", iso_path: "", min_cpu: 1, min_ram_mb: 512, min_disk_gb: 10, is_active: true };

export default function AdminTemplates() {
  const toast = useToast();
  const list = useLoad(() => api<{ items: Template[] }>("/admin/templates"), []);
  const [form, setForm] = useState<{ id?: number; v: typeof blank } | null>(null);
  const [del, setDel] = useState<Template | null>(null);

  const cols: Column<Template>[] = [
    { key: "n", header: "Name", render: (t) => <div><p className="font-medium text-zinc-100">{t.name}</p><p className="text-[11px] capitalize text-muted">{t.os_family} {t.version}</p></div> },
    { key: "t", header: "Source", render: (t) => <div><Badge tone={t.image_path ? "cyan" : "blue"}>{t.image_path ? "Cloud image" : "Install ISO"}</Badge><p className="mt-1 max-w-[260px] truncate font-mono text-[11px] text-muted" title={t.image_path ?? t.iso_path ?? ""}>{t.image_path ?? t.iso_path}</p></div> },
    { key: "f", header: "File on host", render: (t) => <Badge tone={t.file_ok ? "green" : "red"}>{t.file_ok ? "Found" : "Missing"}</Badge> },
    { key: "m", header: "Minimum", render: (t) => `${t.min_cpu} vCPU · ${t.min_ram_mb} MB · ${t.min_disk_gb} GB` },
    { key: "s", header: "Status", render: (t) => <Badge tone={t.is_active ? "green" : "gray"}>{t.is_active ? "Active" : "Inactive"}</Badge> },
    { key: "a", header: "Actions", className: "text-right", render: (t) => (
      <div className="flex justify-end gap-0.5">
        <button className="btn-icon" title="Edit" onClick={() => setForm({ id: t.id, v: { name: t.name, os_family: t.os_family, version: t.version, image_path: t.image_path ?? "", iso_path: t.iso_path ?? "", min_cpu: t.min_cpu, min_ram_mb: t.min_ram_mb, min_disk_gb: t.min_disk_gb, is_active: !!t.is_active } })}><Pencil size={15} /></button>
        <button className="btn-icon hover:!text-red-400" title="Delete" onClick={() => setDel(t)}><Trash2 size={15} /></button>
      </div>) },
  ];

  return (
    <>
      <PageHeader title="OS Templates" subtitle="Cloud images and ISOs available to the VM wizard" actions={<button className="btn btn-primary" onClick={() => setForm({ v: { ...blank } })}><Plus size={15} /> Add template</button>} />
      <Card>
        {list.error && <ErrorState message={list.error} onRetry={list.reloadFull} />}
        <DataTable columns={cols} rows={list.data?.items ?? []} loading={list.loading && !list.data} rowKey={(t) => t.id}
          empty={<EmptyState icon={<HardDrive size={22} />} title="No templates yet" text="Download a cloud image or ISO to the host (see the deployment guide), then register its absolute path here." />} />
      </Card>
      {form && <TemplateForm init={form.v} id={form.id} onClose={() => setForm(null)} onSaved={() => { setForm(null); list.reload(); }} />}
      <ConfirmDialog open={!!del} danger title="Delete template" confirmLabel="Delete" onClose={() => setDel(null)} message={<>Delete template <b>{del?.name}</b>? The image file on disk is not removed.</>}
        onConfirm={async () => { try { await api(`/admin/templates/${del!.id}`, { method: "DELETE" }); toast.push("success", "Template deleted"); list.reload(); } catch (e) { toast.push("error", errText(e)); } }} />
    </>
  );
}

function TemplateForm({ init, id, onClose, onSaved }: { init: typeof blank; id?: number; onClose: () => void; onSaved: () => void }) {
  const toast = useToast();
  const [f, setF] = useState(init);
  const [busy, setBusy] = useState(false);
  const save = async (e: FormEvent) => {
    e.preventDefault(); setBusy(true);
    try {
      await api(id ? `/admin/templates/${id}` : "/admin/templates", { method: id ? "PUT" : "POST", body: { ...f, image_path: f.image_path.trim() || null, iso_path: f.iso_path.trim() || null } });
      toast.push("success", "Template saved"); onSaved();
    } catch (e2) { toast.push("error", errText(e2)); setBusy(false); }
  };
  return (
    <Modal wide open onClose={onClose} title={id ? "Edit template" : "Add template"} footer={<><button className="btn" onClick={onClose}>Cancel</button><button className="btn btn-primary" form="tpl" disabled={busy}>{busy && <Spinner />}Save</button></>}>
      <form id="tpl" onSubmit={save} className="grid gap-4 sm:grid-cols-2">
        <Field label="Name"><input className="input" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} required minLength={2} /></Field>
        <Field label="Version"><input className="input" value={f.version} onChange={(e) => setF({ ...f, version: e.target.value })} /></Field>
        <Field label="Family"><select className="input" value={f.os_family} onChange={(e) => setF({ ...f, os_family: e.target.value })}>{["linux", "windows", "bsd", "other"].map((o) => <option key={o}>{o}</option>)}</select></Field>
        <div className="flex items-end"><Toggle checked={f.is_active} onChange={(v) => setF({ ...f, is_active: v })} label="Active" /></div>
        <div className="sm:col-span-2"><Field label="Cloud image path (qcow2)" hint="Used as a read-only backing file; supports password/SSH key injection via cloud-init"><input className="input font-mono text-xs" value={f.image_path} placeholder="/var/lib/tvm/images/ubuntu-24.04.img" onChange={(e) => setF({ ...f, image_path: e.target.value })} /></Field></div>
        <div className="sm:col-span-2"><Field label="Install ISO path" hint="Used when no cloud image is set; the VM boots the installer"><input className="input font-mono text-xs" value={f.iso_path} placeholder="/var/lib/tvm/images/debian-12.iso" onChange={(e) => setF({ ...f, iso_path: e.target.value })} /></Field></div>
        <Field label="Min vCPU"><input type="number" min={1} className="input" value={f.min_cpu} onChange={(e) => setF({ ...f, min_cpu: Number(e.target.value) })} /></Field>
        <Field label="Min RAM (MB)"><input type="number" min={128} className="input" value={f.min_ram_mb} onChange={(e) => setF({ ...f, min_ram_mb: Number(e.target.value) })} /></Field>
        <Field label="Min disk (GB)"><input type="number" min={1} className="input" value={f.min_disk_gb} onChange={(e) => setF({ ...f, min_disk_gb: Number(e.target.value) })} /></Field>
      </form>
    </Modal>
  );
}
