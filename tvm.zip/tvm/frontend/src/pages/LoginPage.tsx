import { FormEvent, useState } from "react";
import { Navigate } from "react-router-dom";
import { Server } from "lucide-react";
import { api } from "../api";
import { errText, useAuth } from "../context";
import { Field, Spinner, useLoad } from "../components/ui";

export default function LoginPage() {
  const { user, login, register } = useAuth();
  const cfg = useLoad(() => api<{ panel_name: string; allow_registration: boolean }>("/public-config"), []);
  const [mode, setMode] = useState<"login" | "register">("login");
  const [f, setF] = useState({ identifier: "", email: "", username: "", password: "" });
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  if (user) return <Navigate to="/" replace />;

  const submit = async (e: FormEvent) => {
    e.preventDefault(); setErr(""); setBusy(true);
    try {
      if (mode === "login") await login(f.identifier, f.password);
      else await register(f.email, f.username, f.password);
    } catch (e2) { setErr(errText(e2)); setBusy(false); }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-bg p-4">
      <div className="w-full max-w-sm">
        <div className="mb-6 flex flex-col items-center gap-2">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl border border-accent/40 bg-accent/10 shadow-glow"><Server size={22} className="text-accent" /></div>
          <h1 className="text-xl font-bold text-zinc-50">TVM <span className="text-accent">Panel</span></h1>
          <p className="text-xs text-muted">Sign in to manage your virtual machines</p>
        </div>
        <form onSubmit={submit} className="card space-y-4 p-5">
          {mode === "login" ? (
            <Field label="Email or username"><input className="input" value={f.identifier} onChange={(e) => setF({ ...f, identifier: e.target.value })} autoFocus autoComplete="username" required /></Field>
          ) : (<>
            <Field label="Email"><input type="email" className="input" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} required /></Field>
            <Field label="Username"><input className="input" value={f.username} onChange={(e) => setF({ ...f, username: e.target.value })} required /></Field>
          </>)}
          <Field label="Password" hint={mode === "register" ? "At least 8 characters" : undefined}>
            <input type="password" className="input" value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} autoComplete={mode === "login" ? "current-password" : "new-password"} required />
          </Field>
          {err && <p className="rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-xs text-red-300" role="alert">{err}</p>}
          <button className="btn btn-primary w-full !py-2" disabled={busy}>{busy && <Spinner />}{mode === "login" ? "Sign in" : "Create account"}</button>
          {cfg.data?.allow_registration && (
            <button type="button" className="w-full text-center text-xs text-muted hover:text-zinc-200" onClick={() => { setMode(mode === "login" ? "register" : "login"); setErr(""); }}>
              {mode === "login" ? "No account? Register" : "Have an account? Sign in"}
            </button>
          )}
        </form>
      </div>
    </div>
  );
}
