import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, ArrowRight, Check, Cpu, HardDrive, Loader2, MemoryStick, Network, Server } from "lucide-react";
import clsx from "clsx";
import { api, fmtRam, qs } from "../api";
import { errText, useToast } from "../context";
import type { Page, Template, User } from "../types";
import { Card, EmptyState, ErrorState, Field, PageHeader, Spinner, useLoad } from "../components/ui";

interface Cfg { name: string; template_id: number | null; cpu: number; ram_mb: number; disk_gb: number; root_password: string; ssh_key: string; owner_id: number | null }
interface TplResp { items: Template[]; limits: { max_cpu: number; max_ram_mb: number; max_disk_gb: number }; network: string }

const STEPS = ["Operating system", "Resources", "Network & access", "Review"];

export default function CreateVMPage({ admin }: { admin?: boolean }) {
  const nav = useNavigate();
  const toast = useToast();
  const tpls = useLoad(() => api<TplResp>("/templates"), []);
  const users = useLoad(() => (admin ? api<Page<User>>(`/admin/users${qs({ page_size: 100 })}`) : Promise.resolve(null)), [admin]);
  const [step, setStep] = useState(0);
  const [busy, setBusy] = useState(false);
  const [cfg, setCfg] = useState<Cfg>({ name: "", template_id: null, cpu: 1, ram_mb: 1024, disk_gb: 20, root_password: "", ssh_key: "", owner_id: null });
  const set = <K extends keyof Cfg>(k: K, v: Cfg[K]) => setCfg((c) => ({ ...c, [k]: v }));

  const tpl = useMemo(() => tpls.data?.items.find((t) => t.id === cfg.template_id) ?? null, [tpls.data, cfg.template_id]);
  const lim = tpls.data?.limits;

  useEffect(() => {
    if (tpl) setCfg((c) => ({ ...c, cpu: Math.max(c.cpu, tpl.min_cpu), ram_mb: Math.max(c.ram_mb, tpl.min_ram_mb), disk_gb: Math.max(c.disk_gb, tpl.min_disk_gb) }));
  }, [tpl]);

  const nameOk = /^[A-Za-z0-9][A-Za-z0-9 _-]{1,62}$/.test(cfg.name.trim());
  const resOk = !!tpl && !!lim && cfg.cpu >= tpl.min_cpu && cfg.cpu <= lim.max_cpu && cfg.ram_mb >= tpl.min_ram_mb && cfg.ram_mb <= lim.max_ram_mb && cfg.disk_gb >= tpl.min_disk_gb && cfg.disk_gb <= lim.max_disk_gb;
  const canNext = [!!tpl && nameOk, resOk, true, true][step];

  const submit = async () => {
    setBusy(true);
    try {
      const vm = await api<{ id: number }>("/vms", { method: "POST", body: {
        name: cfg.name.trim(), template_id: cfg.template_id, cpu: cfg.cpu, ram_mb: cfg.ram_mb, disk_gb: cfg.disk_gb,
        root_password: cfg.root_password || null, ssh_key: cfg.ssh_key.trim() || null, owner_id: cfg.owner_id,
      } });
      toast.push("success", `${cfg.name} created and started`);
      nav(`${admin ? "/admin" : ""}/vms/${vm.id}`);
    } catch (e) { toast.push("error", errText(e)); setBusy(false); }
  };

  const base = admin ? "/admin" : "";
  return (
    <>
      <PageHeader title="Create Virtual Machine" subtitle="Provision a new KVM guest" />
      <ol className="mb-4 flex flex-wrap gap-2">
        {STEPS.map((s, i) => (
          <li key={s} className={clsx("flex items-center gap-2 rounded-full border px-3 py-1 text-xs font-medium", i === step ? "border-accent/50 bg-accent/10 text-accent" : i < step ? "border-emerald-500/30 text-emerald-300" : "border-line text-muted")}>
            <span className="flex h-4 w-4 items-center justify-center rounded-full bg-panel2 text-[10px]">{i < step ? <Check size={10} /> : i + 1}</span>{s}
          </li>
        ))}
      </ol>

      <Card className="p-4 sm:p-5">
        {tpls.error && <ErrorState message={tpls.error} onRetry={tpls.reloadFull} />}
        {tpls.loading && <div className="flex justify-center py-10"><Spinner size={22} /></div>}
        {tpls.data && tpls.data.items.length === 0 && (
          <EmptyState icon={<HardDrive size={22} />} title="No OS templates available" text={admin ? "Add an OS template (cloud image or ISO) first." : "An administrator needs to add an OS template before VMs can be created."}
            action={admin ? <button className="btn btn-primary" onClick={() => nav("/admin/templates")}>Manage templates</button> : undefined} />
        )}

        {tpls.data && tpls.data.items.length > 0 && lim && <>
          {step === 0 && (
            <div className="space-y-4">
              <Field label="VM name" hint="2–63 characters: letters, digits, space, _ and -">
                <input className="input" value={cfg.name} onChange={(e) => set("name", e.target.value)} placeholder="web-server-01" maxLength={63} autoFocus />
              </Field>
              {admin && (
                <Field label="Owner" hint="Defaults to you">
                  <select className="input" value={cfg.owner_id ?? ""} onChange={(e) => set("owner_id", e.target.value ? Number(e.target.value) : null)}>
                    <option value="">Myself</option>
                    {users.data?.items.map((u) => <option key={u.id} value={u.id}>{u.username} ({u.email})</option>)}
                  </select>
                </Field>
              )}
              <div>
                <span className="label">Operating system</span>
                <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
                  {tpls.data.items.map((t) => (
                    <button key={t.id} type="button" onClick={() => set("template_id", t.id)}
                      className={clsx("rounded-lg border p-3 text-left transition", cfg.template_id === t.id ? "border-accent/60 bg-accent/10 shadow-glow" : "border-line bg-panel2 hover:border-zinc-600")}>
                      <p className="font-medium text-zinc-100">{t.name}</p>
                      <p className="mt-0.5 text-[11px] capitalize text-muted">{t.os_family}{t.version && ` ${t.version}`} · min {t.min_cpu} vCPU / {fmtRam(t.min_ram_mb)} / {t.min_disk_gb} GB</p>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {step === 1 && tpl && (
            <div className="grid gap-5 md:grid-cols-3">
              {([
                ["CPU cores", "cpu", tpl.min_cpu, lim.max_cpu, 1, `${cfg.cpu} vCPU`, <Cpu size={14} key="c" />],
                ["Memory", "ram_mb", tpl.min_ram_mb, lim.max_ram_mb, 256, fmtRam(cfg.ram_mb), <MemoryStick size={14} key="m" />],
                ["Disk", "disk_gb", tpl.min_disk_gb, lim.max_disk_gb, 5, `${cfg.disk_gb} GB`, <HardDrive size={14} key="d" />],
              ] as const).map(([label, key, min, max, stp, shown, ic]) => (
                <div key={key} className="rounded-lg border border-line bg-panel2 p-3">
                  <div className="mb-2 flex items-center justify-between"><span className="flex items-center gap-1.5 text-xs font-medium text-muted">{ic}{label}</span><span className="font-semibold text-zinc-100">{shown}</span></div>
                  <input type="range" className="w-full accent-[rgb(var(--accent))]" min={min} max={Math.min(max, key === "cpu" ? 32 : key === "ram_mb" ? 65536 : 1000)} step={stp} value={cfg[key]} onChange={(e) => set(key, Number(e.target.value))} />
                  <input type="number" className="input mt-2" min={min} max={max} step={stp} value={cfg[key]} onChange={(e) => set(key, Number(e.target.value))} />
                  <p className="mt-1 text-[11px] text-muted">Min {key === "ram_mb" ? fmtRam(min) : min} · max {key === "ram_mb" ? fmtRam(max) : max}</p>
                </div>
              ))}
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <div className="flex items-center gap-3 rounded-lg border border-line bg-panel2 p-3">
                <Network size={18} className="text-cyan-300" />
                <div><p className="font-medium text-zinc-100">Network: {tpls.data.network}</p><p className="text-xs text-muted">A virtio NIC is attached to this host network; the IP address appears on the VM page once the guest has leased one.</p></div>
              </div>
              {tpl?.supports_credentials ? (<>
                <Field label="Root password (optional)" hint="8–64 chars; letters, digits and !@#%^*_+=.,- only. Applied via cloud-init.">
                  <input type="password" className="input" value={cfg.root_password} onChange={(e) => set("root_password", e.target.value)} autoComplete="new-password" />
                </Field>
                <Field label="SSH public key (optional)">
                  <textarea className="input min-h-[80px] font-mono text-xs" value={cfg.ssh_key} onChange={(e) => set("ssh_key", e.target.value)} placeholder="ssh-ed25519 AAAA… user@host" />
                </Field>
              </>) : <p className="text-xs text-muted">This template boots an installer ISO, so credentials are set during installation in the web console.</p>}
            </div>
          )}

          {step === 3 && tpl && (
            <dl className="grid gap-x-8 gap-y-3 sm:grid-cols-2">
              {[["Name", cfg.name.trim()], ["Operating system", tpl.name], ["CPU", `${cfg.cpu} vCPU`], ["Memory", fmtRam(cfg.ram_mb)], ["Disk", `${cfg.disk_gb} GB`], ["Network", tpls.data.network],
                ["Credentials", cfg.root_password || cfg.ssh_key ? [cfg.root_password && "root password", cfg.ssh_key && "SSH key"].filter(Boolean).join(" + ") : "None / installer"]].map(([k, v]) => (
                <div key={k} className="flex justify-between border-b border-line pb-2"><dt className="text-muted">{k}</dt><dd className="font-medium text-zinc-100">{v}</dd></div>
              ))}
            </dl>
          )}

          <div className="mt-6 flex items-center justify-between border-t border-line pt-4">
            <button className="btn" disabled={busy} onClick={() => (step === 0 ? nav(`${base}/vms`) : setStep(step - 1))}><ArrowLeft size={14} /> {step === 0 ? "Cancel" : "Back"}</button>
            {step < 3
              ? <button className="btn btn-primary" disabled={!canNext} onClick={() => setStep(step + 1)}>Next <ArrowRight size={14} /></button>
              : <button className="btn btn-primary" disabled={busy} onClick={submit}>{busy ? <Loader2 size={14} className="animate-spin" /> : <Server size={14} />} Create & start VM</button>}
          </div>
        </>}
      </Card>
    </>
  );
}
