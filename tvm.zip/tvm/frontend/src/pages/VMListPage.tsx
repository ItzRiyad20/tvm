import { useEffect, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { Cpu, LayoutGrid, List, MemoryStick, Play, Plus, RefreshCw, Search, Server, Square } from "lucide-react";
import clsx from "clsx";
import { api, fmtRam, qs } from "../api";
import type { Page, Summary, VM } from "../types";
import { VMActions, VMCard } from "../components/VMParts";
import { Card, Column, DataTable, EmptyState, ErrorState, PageHeader, Pagination, StatCard, StatusBadge, useDebounced, useLoad } from "../components/ui";

const FILTERS = [["", "All"], ["running", "Running"], ["stopped", "Stopped"], ["error", "Error"]];

/** Shared by "My Virtual Machines" (scope=mine) and admin "All VMs" (scope=all). */
export default function VMListPage({ scope }: { scope: "mine" | "all" }) {
  const admin = scope === "all";
  const base = admin ? "/admin" : "";
  const [params] = useSearchParams();
  const [search, setSearch] = useState(params.get("search") ?? "");
  const [status, setStatus] = useState("");
  const [sort, setSort] = useState("created");
  const [order, setOrder] = useState<"asc" | "desc">("desc");
  const [page, setPage] = useState(1);
  const [view, setView] = useState<"list" | "grid">((localStorage.getItem("tvm_view") as "list" | "grid") || "list");
  const q = useDebounced(search);

  useEffect(() => { setSearch(params.get("search") ?? ""); }, [params]);
  useEffect(() => { setPage(1); }, [q, status, sort, order]);

  const pageSize = view === "grid" ? 12 : 10;
  const sum = useLoad(() => api<Summary>(`/vms/summary${qs({ scope })}`), [scope], 10);
  const list = useLoad(() => api<Page<VM>>(`/vms${qs({ scope, search: q, status, sort, order, page, page_size: pageSize })}`), [scope, q, status, sort, order, page, pageSize], 10);
  const refresh = () => { sum.reload(); list.reload(); };
  const onSort = (k: string) => { if (sort === k) setOrder(order === "asc" ? "desc" : "asc"); else { setSort(k); setOrder("asc"); } };

  const cols: Column<VM>[] = [
    { key: "name", header: "VM Name", sortable: true, render: (v) => (
      <Link to={`${base}/vms/${v.id}`} className="group flex items-center gap-2.5">
        <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-line bg-panel2 text-accent"><Server size={15} /></span>
        <span><span className="block font-medium text-zinc-100 group-hover:text-accent">{v.name}</span><span className="text-[11px] text-muted">#{v.id}{admin && v.owner_name ? ` · ${v.owner_name}` : ""}</span></span>
      </Link>) },
    { key: "os", header: "OS", sortable: true, render: (v) => <span className="text-zinc-300">{v.os_name}</span> },
    { key: "status", header: "Status", sortable: true, render: (v) => <StatusBadge status={v.status} /> },
    { key: "cpu", header: "CPU", sortable: true, render: (v) => `${v.cpu} vCPU` },
    { key: "ram", header: "RAM", sortable: true, render: (v) => fmtRam(v.ram_mb) },
    { key: "disk", header: "Storage", sortable: true, render: (v) => `${v.disk_gb} GB` },
    { key: "ip", header: "Network / IP", render: (v) => <span className="font-mono text-xs text-zinc-300">{v.ip_address ?? "—"}</span> },
    { key: "actions", header: "Actions", className: "text-right", render: (v) => <VMActions vm={v} onDone={refresh} base={base} /> },
  ];

  const newBtn = <Link to={admin ? "/admin/vms/new" : "/vms/new"} className="btn btn-primary"><Plus size={15} /> New VM</Link>;
  const emptyFiltered = !!(q || status);

  return (
    <>
      <PageHeader title={admin ? "All Virtual Machines" : "My Virtual Machines"} subtitle={admin ? "Every VM on this host" : "Manage your virtual machines"}
        actions={<><button className="btn" onClick={refresh}><RefreshCw size={14} className={clsx((list.loading || sum.loading) && "animate-spin")} /> Refresh</button>{newBtn}</>} />

      <div className="mb-4 grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label="Total VMs" value={sum.data?.total ?? 0} icon={<Server size={18} />} tone="purple" loading={sum.loading} />
        <StatCard label="Running" value={sum.data?.running ?? 0} icon={<Play size={18} />} tone="green" loading={sum.loading} />
        <StatCard label="Stopped" value={sum.data?.stopped ?? 0} icon={<Square size={18} />} tone="red" loading={sum.loading} />
        <StatCard label="Total RAM" value={fmtRam(sum.data?.total_ram_mb ?? 0)} icon={<MemoryStick size={18} />} tone="cyan" loading={sum.loading} />
      </div>

      <Card>
        <div className="flex flex-wrap items-center gap-2 border-b border-line p-3">
          <div className="relative min-w-[200px] flex-1">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted" />
            <input className="input pl-8" placeholder="Search by name, ID, OS or IP…" value={search} onChange={(e) => setSearch(e.target.value)} />
          </div>
          <div className="flex rounded-lg border border-line bg-panel2 p-0.5">
            {FILTERS.map(([v, l]) => (
              <button key={v} onClick={() => setStatus(v)} className={clsx("rounded-md px-2.5 py-1 text-xs font-medium transition", status === v ? "bg-accent/15 text-accent" : "text-muted hover:text-zinc-200")}>{l}</button>
            ))}
          </div>
          <div className="flex rounded-lg border border-line bg-panel2 p-0.5">
            {([["list", <List size={14} key="l" />], ["grid", <LayoutGrid size={14} key="g" />]] as const).map(([v, ic]) => (
              <button key={v} aria-label={`${v} view`} onClick={() => { setView(v); localStorage.setItem("tvm_view", v); }} className={clsx("rounded-md px-2 py-1 transition", view === v ? "bg-accent/15 text-accent" : "text-muted hover:text-zinc-200")}>{ic}</button>
            ))}
          </div>
        </div>

        {list.error && <ErrorState message={list.error} onRetry={list.reloadFull} />}
        {view === "list" ? (
          <DataTable columns={cols} rows={list.data?.items ?? []} loading={list.loading && !list.data} rowKey={(v) => v.id} sort={sort} order={order} onSort={onSort}
            empty={<EmptyState icon={<Cpu size={22} />} title={emptyFiltered ? "No VMs match your filters" : "No virtual machines yet"} text={emptyFiltered ? "Try a different search or status filter." : "Create your first VM to get started."} action={emptyFiltered ? undefined : newBtn} />} />
        ) : (
          <div className="p-3">
            {(list.data?.items ?? []).length === 0 && !list.loading
              ? <EmptyState icon={<Cpu size={22} />} title={emptyFiltered ? "No VMs match your filters" : "No virtual machines yet"} action={emptyFiltered ? undefined : newBtn} />
              : <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
                  {list.loading && !list.data ? Array.from({ length: 6 }).map((_, i) => <div key={i} className="skeleton h-36" />)
                    : list.data!.items.map((v) => <VMCard key={v.id} vm={v} onDone={refresh} base={base} showOwner={admin} />)}
                </div>}
          </div>
        )}
        <Pagination page={page} pageSize={pageSize} total={list.data?.total ?? 0} onPage={setPage} />
      </Card>
    </>
  );
}
