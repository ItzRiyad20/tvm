import { useRef, useState } from "react";
import { Cpu, HardDrive, MemoryStick, Network } from "lucide-react";
import { api, fmtBytes, fmtRam, fmtUptime } from "../api";
import type { HostInfo } from "../types";
import { Card, CardHeader, Column, DataTable, EmptyState, ErrorState, PageHeader, ProgressBar, Sparkline, StatCard, loadTone, useLoad } from "../components/ui";

interface Mon {
  host: HostInfo; net_rx_bytes: number; net_tx_bytes: number;
  vms: { id: number; name: string; owner: string; cpu_percent: number; mem_used_mb: number; mem_total_mb: number }[];
}

export default function AdminMonitoring() {
  const [cpu, setCpu] = useState<number[]>([]);
  const [mem, setMem] = useState<number[]>([]);
  const [net, setNet] = useState<number[]>([]);
  const prev = useRef<{ t: number; b: number } | null>(null);
  const [rate, setRate] = useState({ rx: 0, tx: 0 });
  const prevRx = useRef<{ t: number; rx: number; tx: number } | null>(null);

  const mon = useLoad(async () => {
    const d = await api<Mon>("/admin/monitoring");
    setCpu((h) => [...h, d.host.cpu_percent].slice(-60));
    setMem((h) => [...h, d.host.mem_percent].slice(-60));
    const now = Date.now(), p = prevRx.current;
    if (p && now > p.t) {
      const rx = Math.max(0, ((d.net_rx_bytes - p.rx) / (now - p.t)) * 1000), tx = Math.max(0, ((d.net_tx_bytes - p.tx) / (now - p.t)) * 1000);
      setRate({ rx, tx }); setNet((h) => [...h, rx + tx].slice(-60));
    }
    prevRx.current = { t: now, rx: d.net_rx_bytes, tx: d.net_tx_bytes };
    void prev;
    return d;
  }, [], 3);

  const h = mon.data?.host;
  const cols: Column<Mon["vms"][number]>[] = [
    { key: "n", header: "VM", render: (v) => <span className="font-medium text-zinc-100">{v.name}</span> },
    { key: "o", header: "Owner", render: (v) => v.owner },
    { key: "c", header: "CPU", render: (v) => <div className="flex w-40 items-center gap-2"><div className="flex-1"><ProgressBar value={v.cpu_percent} tone={loadTone(v.cpu_percent)} /></div><span className="w-10 text-right text-xs">{v.cpu_percent}%</span></div> },
    { key: "m", header: "Memory", render: (v) => `${fmtRam(v.mem_used_mb)} / ${fmtRam(v.mem_total_mb)}` },
  ];

  return (
    <>
      <PageHeader title="System Monitoring" subtitle="Live host and guest metrics (refreshes every 3 seconds)" />
      {mon.error && <Card className="mb-4"><ErrorState message={mon.error} onRetry={mon.reloadFull} /></Card>}
      <div className="mb-4 grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label="Host CPU" value={h ? `${h.cpu_percent}%` : "—"} sub={h ? `${h.cpu_count} cores` : undefined} icon={<Cpu size={18} />} tone="purple" loading={mon.loading && !h} />
        <StatCard label="Host memory" value={h ? `${h.mem_percent}%` : "—"} sub={h ? `${fmtRam(h.mem_used_mb)} / ${fmtRam(h.mem_total_mb)}` : undefined} icon={<MemoryStick size={18} />} tone="cyan" loading={mon.loading && !h} />
        <StatCard label="Storage" value={h ? `${h.disk_percent}%` : "—"} sub={h ? `${h.disk_used_gb} / ${h.disk_total_gb} GB` : undefined} icon={<HardDrive size={18} />} tone="blue" loading={mon.loading && !h} />
        <StatCard label="Uptime" value={h ? fmtUptime(Math.floor(Date.now() / 1000 - h.boot_time)) : "—"} sub={h ? `Load ${h.load.join(" / ")}` : undefined} icon={<Network size={18} />} tone="green" loading={mon.loading && !h} />
      </div>
      <div className="mb-4 grid gap-4 md:grid-cols-3">
        <Card className="p-4"><p className="mb-1 text-xs text-muted">CPU %</p><Sparkline data={cpu} color="#a78bfa" height={64} /></Card>
        <Card className="p-4"><p className="mb-1 text-xs text-muted">Memory %</p><Sparkline data={mem} color="#22d3ee" height={64} /></Card>
        <Card className="p-4"><p className="mb-1 text-xs text-muted">Network ↓ {fmtBytes(rate.rx)}/s · ↑ {fmtBytes(rate.tx)}/s</p><Sparkline data={net} color="#34d399" height={64} max={Math.max(1, ...net)} /></Card>
      </div>
      <Card>
        <CardHeader title="Running VMs by CPU" />
        <DataTable columns={cols} rows={mon.data?.vms ?? []} loading={mon.loading && !mon.data} rowKey={(v) => v.id} empty={<EmptyState title="No running VMs" />} />
      </Card>
    </>
  );
}
