import { useEffect, useRef, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { ArrowLeft, Keyboard, Maximize } from "lucide-react";
import RFB from "@novnc/novnc/lib/rfb";
import { api } from "../api";
import type { VM } from "../types";
import { Card, ErrorState, Spinner, useLoad } from "../components/ui";

export default function ConsolePage({ admin }: { admin?: boolean }) {
  const { id } = useParams();
  const base = admin ? "/admin" : "";
  const vm = useLoad(() => api<VM>(`/vms/${id}`), [id]);
  const box = useRef<HTMLDivElement>(null);
  const rfb = useRef<any>(null);
  const [state, setState] = useState<"connecting" | "connected" | "closed">("connecting");
  const [reason, setReason] = useState("");

  useEffect(() => {
    if (!vm.data || vm.data.status !== "running" || !box.current) return;
    const proto = location.protocol === "https:" ? "wss" : "ws";
    const r = new RFB(box.current, `${proto}://${location.host}/api/vms/${id}/console`, { shared: true });
    r.scaleViewport = true;
    r.resizeSession = false;
    r.addEventListener("connect", () => setState("connected"));
    r.addEventListener("disconnect", (e: any) => { setState("closed"); setReason(e.detail?.clean ? "" : "Connection lost"); });
    rfb.current = r;
    return () => { try { r.disconnect(); } catch { /* already closed */ } };
  }, [vm.data?.status, id]); // eslint-disable-line react-hooks/exhaustive-deps

  const notRunning = vm.data && vm.data.status !== "running";
  return (
    <>
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-3">
          <Link to={`${base}/vms/${id}`} className="btn-icon border-line" aria-label="Back"><ArrowLeft size={16} /></Link>
          <div><h1 className="text-lg font-semibold text-zinc-50">Console{vm.data ? ` — ${vm.data.name}` : ""}</h1><p className="text-xs text-muted">Click inside the screen to send keyboard input</p></div>
        </div>
        <div className="flex gap-2">
          <button className="btn" disabled={state !== "connected"} onClick={() => rfb.current?.sendCtrlAltDel()}><Keyboard size={14} /> Ctrl+Alt+Del</button>
          <button className="btn" disabled={state !== "connected"} onClick={() => box.current?.requestFullscreen()}><Maximize size={14} /> Fullscreen</button>
        </div>
      </div>
      <Card className="overflow-hidden">
        {vm.error && <ErrorState message={vm.error} />}
        {notRunning && <ErrorState message="The VM is not running. Start it to use the console." />}
        {state === "connecting" && vm.data?.status === "running" && <div className="flex items-center gap-2 px-4 py-3 text-xs text-muted"><Spinner /> Connecting…</div>}
        {state === "closed" && <ErrorState message={reason || "Console disconnected."} onRetry={() => location.reload()} />}
        <div ref={box} className="h-[70vh] w-full bg-black" />
      </Card>
    </>
  );
}
