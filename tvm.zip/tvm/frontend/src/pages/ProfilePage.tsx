import { FormEvent, useState } from "react";
import { Save } from "lucide-react";
import { api, fmtDate } from "../api";
import { errText, useAuth, useToast } from "../context";
import type { User } from "../types";
import { Badge, Card, CardHeader, Field, PageHeader, Spinner } from "../components/ui";

export default function ProfilePage() {
  const { user, refresh } = useAuth();
  const toast = useToast();
  const [email, setEmail] = useState(user?.email ?? "");
  const [cur, setCur] = useState("");
  const [pw, setPw] = useState("");
  const [pw2, setPw2] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (pw && pw !== pw2) return toast.push("error", "New passwords do not match");
    setBusy(true);
    try {
      await api<User>("/auth/me", { method: "PATCH", body: { email: email !== user?.email ? email : undefined, current_password: pw ? cur : undefined, new_password: pw || undefined } });
      await refresh(); setCur(""); setPw(""); setPw2("");
      toast.push("success", "Profile updated");
    } catch (e2) { toast.push("error", errText(e2)); }
    finally { setBusy(false); }
  };

  return (
    <>
      <PageHeader title="My Profile" subtitle="Account details and security" />
      <div className="grid gap-4 lg:grid-cols-3">
        <Card>
          <CardHeader title="Account" />
          <dl className="divide-y divide-line text-[13px]">
            {[["Username", user?.username], ["Role", user?.role], ["Virtual machines", String(user?.vm_count ?? 0)], ["Member since", fmtDate(user?.created_at)], ["Last sign-in", fmtDate(user?.last_login)]].map(([k, v]) => (
              <div key={k} className="flex justify-between px-4 py-2.5"><dt className="text-muted">{k}</dt><dd className="font-medium capitalize text-zinc-100">{k === "Role" ? <Badge tone={v === "admin" ? "purple" : "gray"}>{v}</Badge> : v}</dd></div>
            ))}
          </dl>
        </Card>
        <Card className="lg:col-span-2">
          <CardHeader title="Edit profile" />
          <form onSubmit={submit} className="space-y-4 p-4">
            <Field label="Email"><input type="email" className="input" value={email} onChange={(e) => setEmail(e.target.value)} required /></Field>
            <div className="grid gap-4 sm:grid-cols-3">
              <Field label="Current password"><input type="password" className="input" value={cur} onChange={(e) => setCur(e.target.value)} autoComplete="current-password" /></Field>
              <Field label="New password" hint="Min 8 characters"><input type="password" className="input" value={pw} onChange={(e) => setPw(e.target.value)} autoComplete="new-password" /></Field>
              <Field label="Repeat new password"><input type="password" className="input" value={pw2} onChange={(e) => setPw2(e.target.value)} autoComplete="new-password" /></Field>
            </div>
            <button className="btn btn-primary" disabled={busy}>{busy ? <Spinner /> : <Save size={14} />} Save changes</button>
          </form>
        </Card>
      </div>
    </>
  );
}
