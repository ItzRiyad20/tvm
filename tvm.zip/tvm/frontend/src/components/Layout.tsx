import { ReactNode, useEffect, useRef, useState } from "react";
import { Link, NavLink, Outlet, useLocation, useNavigate } from "react-router-dom";
import {
  Activity, Bell, ChevronDown, ChevronRight, Cpu, FileText, HardDrive, LayoutDashboard, LogOut, Maximize, Menu, Minimize,
  PanelLeftClose, PanelLeftOpen, Palette, PlusCircle, Search, Server, Settings, ShieldCheck, User as UserIcon, Users, Undo2, Wifi, WifiOff, X,
} from "lucide-react";
import clsx from "clsx";
import { api, timeAgo } from "../api";
import { useAuth } from "../context";
import type { Activity as ActivityT } from "../types";
import { useLoad } from "./ui";

export function Logo({ compact }: { compact?: boolean }) {
  return (
    <div className="flex items-center gap-2.5">
      <div className="flex h-8 w-8 items-center justify-center rounded-lg border border-accent/40 bg-accent/10 shadow-glow">
        <Server size={16} className="text-accent" />
      </div>
      {!compact && <div className="leading-tight"><p className="text-sm font-bold tracking-wide text-zinc-50">TVM <span className="text-accent">Panel</span></p><p className="text-[10px] uppercase tracking-widest text-muted">Virtualization</p></div>}
    </div>
  );
}

interface Item { to: string; label: string; icon: ReactNode; end?: boolean }
interface Group { title?: string; items: Item[] }

function useDropdown() {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const h = (e: MouseEvent) => ref.current && !ref.current.contains(e.target as Node) && setOpen(false);
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);
  return { open, setOpen, ref };
}

function Sidebar({ collapsed, setCollapsed, mobileOpen, closeMobile, admin }: { collapsed: boolean; setCollapsed: (v: boolean) => void; mobileOpen: boolean; closeMobile: () => void; admin: boolean }) {
  const { user, logout } = useAuth();
  const nav = useNavigate();
  const [closedGroups, setClosedGroups] = useState<Record<string, boolean>>({});
  const profile = useDropdown();

  const groups: Group[] = admin
    ? [
        { items: [
          { to: "/admin", label: "Dashboard", icon: <LayoutDashboard size={17} />, end: true },
          { to: "/", label: "Back to User Panel", icon: <Undo2 size={17} />, end: true },
        ] },
        { title: "Management", items: [
          { to: "/admin/vms", label: "All VMs", icon: <Server size={17} />, end: true },
          { to: "/admin/vms/new", label: "Create VM", icon: <PlusCircle size={17} /> },
          { to: "/admin/users", label: "Users", icon: <Users size={17} /> },
        ] },
        { title: "Configuration", items: [
          { to: "/admin/settings", label: "Settings", icon: <Settings size={17} /> },
          { to: "/admin/templates", label: "OS Templates", icon: <HardDrive size={17} /> },
        ] },
        { title: "System", items: [
          { to: "/admin/monitoring", label: "System Monitoring", icon: <Cpu size={17} /> },
          { to: "/admin/logs", label: "Activity Logs", icon: <FileText size={17} /> },
        ] },
      ]
    : [
        { items: [
          { to: "/", label: "Dashboard", icon: <LayoutDashboard size={17} />, end: true },
          { to: "/vms", label: "My Virtual Machines", icon: <Server size={17} /> },
          { to: "/profile", label: "My Profile", icon: <UserIcon size={17} /> },
          ...(user?.role === "admin" ? [{ to: "/admin", label: "Admin Panel", icon: <ShieldCheck size={17} /> }] : []),
        ] },
      ];

  return (
    <>
      {mobileOpen && <div className="fixed inset-0 z-30 bg-black/60 lg:hidden" onClick={closeMobile} />}
      <aside className={clsx(
        "fixed inset-y-0 left-0 z-40 flex flex-col border-r border-line bg-[#0c0c10] transition-all duration-200",
        collapsed ? "lg:w-[68px]" : "lg:w-60", "w-60", mobileOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0",
      )}>
        <div className="flex h-14 items-center justify-between border-b border-line px-4">
          <Link to={admin ? "/admin" : "/"} onClick={closeMobile}><Logo compact={collapsed} /></Link>
          <button className="btn-icon lg:hidden" onClick={closeMobile} aria-label="Close menu"><X size={16} /></button>
        </div>

        <nav className="flex-1 space-y-3 overflow-y-auto px-2.5 py-3">
          {groups.map((g, gi) => {
            const closed = g.title ? closedGroups[g.title] : false;
            return (
              <div key={gi}>
                {g.title && !collapsed && (
                  <button className="mb-1 flex w-full items-center justify-between px-2 text-[10px] font-semibold uppercase tracking-widest text-muted hover:text-zinc-300"
                    onClick={() => setClosedGroups((s) => ({ ...s, [g.title!]: !s[g.title!] }))}>
                    {g.title}{closed ? <ChevronRight size={12} /> : <ChevronDown size={12} />}
                  </button>
                )}
                {g.title && collapsed && <div className="mx-2 mb-1 border-t border-line" />}
                {(!closed || collapsed) && (
                  <ul className="space-y-0.5">
                    {g.items.map((it) => (
                      <li key={it.to + it.label}>
                        <NavLink to={it.to} end={it.end} onClick={closeMobile} title={collapsed ? it.label : undefined}
                          className={({ isActive }) => clsx(
                            "group relative flex items-center gap-3 rounded-lg px-3 py-2 text-[13px] font-medium transition",
                            collapsed && "lg:justify-center lg:px-0",
                            isActive ? "bg-accent/10 text-zinc-50" : "text-zinc-400 hover:bg-panel2 hover:text-zinc-100")}>
                          {({ isActive }) => (<>
                            {isActive && <span className="absolute -left-2.5 top-1/2 h-5 w-[3px] -translate-y-1/2 rounded-r bg-accent shadow-glow" />}
                            <span className={clsx(isActive ? "text-accent" : "text-zinc-500 group-hover:text-zinc-300")}>{it.icon}</span>
                            <span className={clsx(collapsed && "lg:hidden")}>{it.label}</span>
                          </>)}
                        </NavLink>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            );
          })}
        </nav>

        <div className="border-t border-line p-2.5">
          <button className="mb-2 hidden w-full items-center justify-center gap-2 rounded-lg py-1.5 text-xs text-muted hover:bg-panel2 hover:text-zinc-200 lg:flex" onClick={() => setCollapsed(!collapsed)}>
            {collapsed ? <PanelLeftOpen size={16} /> : <><PanelLeftClose size={16} /> Collapse</>}
          </button>
          <div className="relative" ref={profile.ref}>
            {profile.open && (
              <div className="absolute bottom-full left-0 mb-2 w-52 overflow-hidden rounded-lg border border-line bg-panel2 shadow-xl">
                <button className="flex w-full items-center gap-2 px-3 py-2 text-left text-[13px] hover:bg-panel" onClick={() => { profile.setOpen(false); nav("/profile"); closeMobile(); }}><UserIcon size={14} /> My Profile</button>
                <button className="flex w-full items-center gap-2 px-3 py-2 text-left text-[13px] text-red-300 hover:bg-panel" onClick={() => logout()}><LogOut size={14} /> Sign out</button>
              </div>
            )}
            <button onClick={() => profile.setOpen(!profile.open)} className={clsx("flex w-full items-center gap-2.5 rounded-lg p-2 hover:bg-panel2", collapsed && "lg:justify-center")}>
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full border border-accent/40 bg-accent/10 text-xs font-bold uppercase text-accent">{user?.username.slice(0, 2)}</div>
              <div className={clsx("min-w-0 flex-1 text-left", collapsed && "lg:hidden")}>
                <p className="truncate text-[13px] font-medium text-zinc-100">{user?.username}</p>
                <p className="truncate text-[11px] capitalize text-muted">{user?.role}</p>
              </div>
              <ChevronDown size={14} className={clsx("text-muted", collapsed && "lg:hidden")} />
            </button>
          </div>
        </div>
      </aside>
    </>
  );
}

const CRUMBS: Record<string, string> = {
  admin: "Admin", vms: "Virtual Machines", new: "Create VM", users: "Users", settings: "Settings", templates: "OS Templates",
  monitoring: "System Monitoring", logs: "Activity Logs", profile: "My Profile", console: "Console",
};
const ACCENTS = [
  { name: "Purple", v: "167 139 250" }, { name: "Blue", v: "96 165 250" }, { name: "Cyan", v: "34 211 238" }, { name: "Green", v: "52 211 153" },
];

function Topbar({ openMobile, admin }: { openMobile: () => void; admin: boolean }) {
  const loc = useLocation();
  const nav = useNavigate();
  const { user, logout } = useAuth();
  const [q, setQ] = useState("");
  const [online, setOnline] = useState(navigator.onLine);
  const [apiOk, setApiOk] = useState(true);
  const [full, setFull] = useState(!!document.fullscreenElement);
  const theme = useDropdown(), notif = useDropdown(), prof = useDropdown();
  const [seen, setSeen] = useState(() => Number(localStorage.getItem("tvm_seen_activity") || 0));
  const acts = useLoad(() => api<ActivityT[]>("/activity?limit=8"), [], 20);

  useEffect(() => {
    const on = () => setOnline(true), off = () => setOnline(false), fs = () => setFull(!!document.fullscreenElement);
    window.addEventListener("online", on); window.addEventListener("offline", off); document.addEventListener("fullscreenchange", fs);
    const t = setInterval(() => api("/health").then(() => setApiOk(true)).catch(() => setApiOk(false)), 15000);
    return () => { window.removeEventListener("online", on); window.removeEventListener("offline", off); document.removeEventListener("fullscreenchange", fs); clearInterval(t); };
  }, []);

  const parts = loc.pathname.split("/").filter(Boolean);
  const crumbs = [{ label: "Home", to: "/" }, ...parts.map((p, i) => ({ label: CRUMBS[p] ?? `#${p}`, to: "/" + parts.slice(0, i + 1).join("/") }))];
  const unread = (acts.data ?? []).filter((a) => a.id > seen).length;
  const setAccent = (v: string) => { document.documentElement.style.setProperty("--accent", v); localStorage.setItem("tvm_accent", v); theme.setOpen(false); };
  const status = online && apiOk;

  return (
    <header className="sticky top-0 z-20 flex h-14 items-center gap-3 border-b border-line bg-bg/90 px-3 backdrop-blur sm:px-5">
      <button className="btn-icon lg:hidden" onClick={openMobile} aria-label="Open menu"><Menu size={18} /></button>
      <nav className="hidden min-w-0 items-center gap-1 text-xs text-muted md:flex" aria-label="Breadcrumb">
        {crumbs.map((c, i) => (
          <span key={c.to} className="flex items-center gap-1">
            {i > 0 && <ChevronRight size={12} />}
            {i === crumbs.length - 1 ? <span className="font-medium text-zinc-200">{c.label}</span> : <Link to={c.to} className="hover:text-zinc-200">{c.label}</Link>}
          </span>
        ))}
      </nav>

      <form className="relative ml-auto max-w-xs flex-1 md:ml-4" onSubmit={(e) => { e.preventDefault(); nav(`${admin ? "/admin/vms" : "/vms"}?search=${encodeURIComponent(q)}`); }}>
        <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted" />
        <input className="input !py-1.5 pl-8" placeholder="Search VMs…" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Global search" />
      </form>

      <div className="flex items-center gap-1">
        <span className={clsx("hidden items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-medium sm:inline-flex", status ? "border-emerald-500/25 bg-emerald-500/10 text-emerald-300" : "border-red-500/25 bg-red-500/10 text-red-300")}>
          {status ? <Wifi size={12} /> : <WifiOff size={12} />}{status ? "Online" : "Offline"}
        </span>

        <div className="relative" ref={theme.ref}>
          <button className="btn-icon" onClick={() => theme.setOpen(!theme.open)} aria-label="Theme"><Palette size={16} /></button>
          {theme.open && (
            <div className="absolute right-0 mt-2 w-40 rounded-lg border border-line bg-panel2 p-2 shadow-xl">
              <p className="px-1 pb-1 text-[10px] uppercase tracking-widest text-muted">Accent</p>
              {ACCENTS.map((a) => (
                <button key={a.name} className="flex w-full items-center gap-2 rounded px-2 py-1.5 text-[13px] hover:bg-panel" onClick={() => setAccent(a.v)}>
                  <span className="h-3 w-3 rounded-full" style={{ background: `rgb(${a.v})` }} />{a.name}
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="relative" ref={notif.ref}>
          <button className="btn-icon relative" aria-label="Notifications" onClick={() => {
            notif.setOpen(!notif.open);
            const max = Math.max(0, ...(acts.data ?? []).map((a) => a.id));
            setSeen(max); localStorage.setItem("tvm_seen_activity", String(max));
          }}>
            <Bell size={16} />{unread > 0 && <span className="absolute right-1 top-1 h-2 w-2 rounded-full bg-accent" />}
          </button>
          {notif.open && (
            <div className="absolute right-0 mt-2 w-80 max-w-[90vw] overflow-hidden rounded-lg border border-line bg-panel2 shadow-xl">
              <p className="border-b border-line px-3 py-2 text-xs font-semibold">Recent activity</p>
              <div className="max-h-80 overflow-y-auto">
                {(acts.data ?? []).length === 0 && <p className="px-3 py-6 text-center text-xs text-muted">No activity yet</p>}
                {(acts.data ?? []).map((a) => (
                  <div key={a.id} className="border-b border-line/60 px-3 py-2 last:border-0">
                    <p className="text-[13px] text-zinc-200">{a.detail || a.action}</p>
                    <p className="text-[11px] text-muted">{timeAgo(a.created_at)}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        <button className="btn-icon hidden sm:inline-flex" aria-label="Toggle fullscreen" onClick={() => (document.fullscreenElement ? document.exitFullscreen() : document.documentElement.requestFullscreen())}>
          {full ? <Minimize size={16} /> : <Maximize size={16} />}
        </button>

        <div className="relative" ref={prof.ref}>
          <button className="ml-1 flex h-8 w-8 items-center justify-center rounded-full border border-accent/40 bg-accent/10 text-xs font-bold uppercase text-accent" onClick={() => prof.setOpen(!prof.open)} aria-label="Profile menu">
            {user?.username.slice(0, 2)}
          </button>
          {prof.open && (
            <div className="absolute right-0 mt-2 w-52 overflow-hidden rounded-lg border border-line bg-panel2 shadow-xl">
              <div className="border-b border-line px-3 py-2"><p className="text-[13px] font-medium">{user?.username}</p><p className="truncate text-[11px] text-muted">{user?.email}</p></div>
              <button className="flex w-full items-center gap-2 px-3 py-2 text-left text-[13px] hover:bg-panel" onClick={() => { prof.setOpen(false); nav("/profile"); }}><UserIcon size={14} /> My Profile</button>
              {user?.role === "admin" && <button className="flex w-full items-center gap-2 px-3 py-2 text-left text-[13px] hover:bg-panel" onClick={() => { prof.setOpen(false); nav(admin ? "/" : "/admin"); }}><ShieldCheck size={14} /> {admin ? "User Panel" : "Admin Panel"}</button>}
              <button className="flex w-full items-center gap-2 px-3 py-2 text-left text-[13px] text-red-300 hover:bg-panel" onClick={() => logout()}><LogOut size={14} /> Sign out</button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}

export default function Layout() {
  const loc = useLocation();
  const admin = loc.pathname === "/admin" || loc.pathname.startsWith("/admin/");
  const [collapsed, setCollapsed] = useState(() => localStorage.getItem("tvm_collapsed") === "1");
  const [mobile, setMobile] = useState(false);
  useEffect(() => { setMobile(false); }, [loc.pathname]);
  useEffect(() => { localStorage.setItem("tvm_collapsed", collapsed ? "1" : "0"); }, [collapsed]);
  useEffect(() => { const a = localStorage.getItem("tvm_accent"); if (a) document.documentElement.style.setProperty("--accent", a); }, []);

  return (
    <div className="min-h-full">
      <Sidebar collapsed={collapsed} setCollapsed={setCollapsed} mobileOpen={mobile} closeMobile={() => setMobile(false)} admin={admin} />
      <div className={clsx("flex min-h-screen flex-col transition-all duration-200", collapsed ? "lg:pl-[68px]" : "lg:pl-60")}>
        <Topbar openMobile={() => setMobile(true)} admin={admin} />
        <main className="flex-1 p-3 sm:p-5"><Outlet /></main>
      </div>
    </div>
  );
}

export { Activity };
