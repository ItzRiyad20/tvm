import { ReactNode, useCallback, useEffect, useRef, useState } from "react";
import { ChevronDown, ChevronLeft, ChevronRight, ChevronUp, Inbox, Loader2, X } from "lucide-react";
import clsx from "clsx";
import type { VMStatus } from "../types";

/* ---------- hooks ---------- */
export function useDebounced<T>(value: T, ms = 300): T {
  const [v, setV] = useState(value);
  useEffect(() => { const t = setTimeout(() => setV(value), ms); return () => clearTimeout(t); }, [value, ms]);
  return v;
}

/** Fetches on mount/deps change and re-fetches every `intervalSec` seconds (0 = off). */
export function useLoad<T>(fn: () => Promise<T>, deps: unknown[], intervalSec = 0) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const fnRef = useRef(fn);
  fnRef.current = fn;
  const run = useCallback(async (silent = false) => {
    if (!silent) setLoading(true);
    try { setData(await fnRef.current()); setError(null); }
    catch (e) { setError(e instanceof Error ? e.message : "Failed to load"); }
    finally { setLoading(false); }
  }, []);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => { run(false); }, deps);
  useEffect(() => {
    if (!intervalSec) return;
    const t = setInterval(() => { if (!document.hidden) run(true); }, intervalSec * 1000);
    return () => clearInterval(t);
  }, [intervalSec, run]);
  return { data, error, loading, reload: () => run(true), reloadFull: () => run(false) };
}

/* ---------- primitives ---------- */
export function Card({ children, className }: { children: ReactNode; className?: string }) {
  return <div className={clsx("card", className)}>{children}</div>;
}

export function CardHeader({ title, icon, actions }: { title: string; icon?: ReactNode; actions?: ReactNode }) {
  return (
    <div className="flex items-center justify-between border-b border-line px-4 py-3">
      <h3 className="flex items-center gap-2 text-[13px] font-semibold text-zinc-100">{icon}{title}</h3>
      {actions}
    </div>
  );
}

const TONES = {
  purple: "text-violet-300 bg-violet-500/10 border-violet-500/25",
  blue: "text-blue-300 bg-blue-500/10 border-blue-500/25",
  cyan: "text-cyan-300 bg-cyan-500/10 border-cyan-500/25",
  green: "text-emerald-300 bg-emerald-500/10 border-emerald-500/25",
  red: "text-red-300 bg-red-500/10 border-red-500/25",
  amber: "text-amber-300 bg-amber-500/10 border-amber-500/25",
  gray: "text-zinc-300 bg-zinc-500/10 border-zinc-500/25",
};
export type Tone = keyof typeof TONES;

export function StatCard({ label, value, icon, tone = "purple", sub, loading }: { label: string; value: ReactNode; icon: ReactNode; tone?: Tone; sub?: string; loading?: boolean }) {
  return (
    <div className="card flex items-center gap-3 p-3.5 transition hover:border-zinc-700 hover:shadow-glow">
      <div className={clsx("flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border", TONES[tone])}>{icon}</div>
      <div className="min-w-0">
        <p className="truncate text-[11px] font-medium uppercase tracking-wider text-muted">{label}</p>
        {loading ? <div className="skeleton mt-1.5 h-6 w-14" /> : <p className="text-xl font-semibold leading-tight text-zinc-50">{value}</p>}
        {sub && <p className="truncate text-[11px] text-muted">{sub}</p>}
      </div>
    </div>
  );
}

const STATUS: Record<VMStatus, { label: string; cls: string; dot: string }> = {
  running: { label: "Running", cls: "text-emerald-300 bg-emerald-500/10 border-emerald-500/25", dot: "bg-emerald-400 live-dot" },
  stopped: { label: "Stopped", cls: "text-red-300 bg-red-500/10 border-red-500/25", dot: "bg-red-400" },
  paused: { label: "Paused", cls: "text-amber-300 bg-amber-500/10 border-amber-500/25", dot: "bg-amber-400" },
  stopping: { label: "Stopping", cls: "text-amber-300 bg-amber-500/10 border-amber-500/25", dot: "bg-amber-400 live-dot" },
  creating: { label: "Creating", cls: "text-cyan-300 bg-cyan-500/10 border-cyan-500/25", dot: "bg-cyan-400 live-dot" },
  error: { label: "Error", cls: "text-red-300 bg-red-500/10 border-red-500/25", dot: "bg-red-400" },
};
export function StatusBadge({ status }: { status: VMStatus }) {
  const s = STATUS[status] ?? STATUS.error;
  return (
    <span className={clsx("inline-flex items-center gap-1.5 rounded-full border px-2 py-0.5 text-[11px] font-medium", s.cls)}>
      <span className={clsx("h-1.5 w-1.5 rounded-full", s.dot)} />{s.label}
    </span>
  );
}

export function Badge({ children, tone = "gray" }: { children: ReactNode; tone?: Tone }) {
  return <span className={clsx("inline-flex items-center rounded-full border px-2 py-0.5 text-[11px] font-medium", TONES[tone])}>{children}</span>;
}

export function Skeleton({ className }: { className?: string }) {
  return <div className={clsx("skeleton h-4", className)} />;
}

export function EmptyState({ title, text, action, icon }: { title: string; text?: string; action?: ReactNode; icon?: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center px-4 py-12 text-center">
      <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-full border border-line bg-panel2 text-muted">{icon ?? <Inbox size={22} />}</div>
      <p className="font-medium text-zinc-100">{title}</p>
      {text && <p className="mt-1 max-w-sm text-xs text-muted">{text}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export function ErrorState({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div className="m-4 flex items-center justify-between gap-3 rounded-lg border border-red-500/30 bg-red-500/5 px-4 py-3 text-red-300">
      <span className="text-[13px]">{message}</span>
      {onRetry && <button className="btn btn-danger" onClick={onRetry}>Retry</button>}
    </div>
  );
}

export function PageHeader({ title, subtitle, actions }: { title: string; subtitle?: string; actions?: ReactNode }) {
  return (
    <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
      <div>
        <h1 className="text-lg font-semibold text-zinc-50">{title}</h1>
        {subtitle && <p className="text-xs text-muted">{subtitle}</p>}
      </div>
      <div className="flex flex-wrap items-center gap-2">{actions}</div>
    </div>
  );
}

export function Spinner({ size = 14 }: { size?: number }) { return <Loader2 size={size} className="animate-spin" />; }

export function ProgressBar({ value, tone = "purple" }: { value: number; tone?: "purple" | "cyan" | "green" | "amber" | "red" }) {
  const c = { purple: "bg-violet-400", cyan: "bg-cyan-400", green: "bg-emerald-400", amber: "bg-amber-400", red: "bg-red-400" }[tone];
  return (
    <div className="h-1.5 w-full overflow-hidden rounded-full bg-panel2">
      <div className={clsx("h-full rounded-full transition-all duration-500", c)} style={{ width: `${Math.max(0, Math.min(100, value))}%` }} />
    </div>
  );
}

export const loadTone = (p: number) => (p >= 90 ? "red" : p >= 75 ? "amber" : "green") as "red" | "amber" | "green";

export function Sparkline({ data, color = "#a78bfa", max = 100, height = 40 }: { data: number[]; color?: string; max?: number; height?: number }) {
  if (data.length < 2) return <div style={{ height }} className="flex items-center text-[11px] text-muted">Collecting data…</div>;
  const w = 200;
  const pts = data.map((v, i) => `${(i / (data.length - 1)) * w},${height - (Math.min(v, max) / max) * (height - 4) - 2}`).join(" ");
  return (
    <svg viewBox={`0 0 ${w} ${height}`} preserveAspectRatio="none" className="w-full" style={{ height }}>
      <polygon points={`0,${height} ${pts} ${w},${height}`} fill={color} opacity="0.12" />
      <polyline points={pts} fill="none" stroke={color} strokeWidth="1.5" vectorEffect="non-scaling-stroke" />
    </svg>
  );
}

/* ---------- dialogs ---------- */
export function Modal({ open, onClose, title, children, footer, wide }: { open: boolean; onClose: () => void; title: string; children: ReactNode; footer?: ReactNode; wide?: boolean }) {
  useEffect(() => {
    if (!open) return;
    const h = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm" onMouseDown={onClose}>
      <div role="dialog" aria-modal="true" aria-label={title} onMouseDown={(e) => e.stopPropagation()}
        className={clsx("card max-h-[90vh] w-full overflow-y-auto shadow-2xl", wide ? "max-w-2xl" : "max-w-md")}>
        <div className="flex items-center justify-between border-b border-line px-4 py-3">
          <h3 className="font-semibold text-zinc-50">{title}</h3>
          <button className="btn-icon" onClick={onClose} aria-label="Close"><X size={16} /></button>
        </div>
        <div className="p-4">{children}</div>
        {footer && <div className="flex justify-end gap-2 border-t border-line px-4 py-3">{footer}</div>}
      </div>
    </div>
  );
}

export function ConfirmDialog({ open, title, message, confirmLabel = "Confirm", danger, onConfirm, onClose }: {
  open: boolean; title: string; message: ReactNode; confirmLabel?: string; danger?: boolean; onConfirm: () => Promise<void> | void; onClose: () => void;
}) {
  const [busy, setBusy] = useState(false);
  const go = async () => { setBusy(true); try { await onConfirm(); } finally { setBusy(false); onClose(); } };
  return (
    <Modal open={open} onClose={busy ? () => {} : onClose} title={title}
      footer={<>
        <button className="btn" onClick={onClose} disabled={busy}>Cancel</button>
        <button className={clsx("btn", danger ? "btn-danger" : "btn-primary")} onClick={go} disabled={busy}>{busy && <Spinner />}{confirmLabel}</button>
      </>}>
      <div className="text-[13px] text-zinc-300">{message}</div>
    </Modal>
  );
}

/* ---------- forms ---------- */
export function Field({ label, hint, children }: { label: string; hint?: string; children: ReactNode }) {
  return <label className="block"><span className="label">{label}</span>{children}{hint && <span className="mt-1 block text-[11px] text-muted">{hint}</span>}</label>;
}

export function Toggle({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button type="button" role="switch" aria-checked={checked} onClick={() => onChange(!checked)} className="flex items-center gap-2.5 text-[13px] text-zinc-200">
      <span className={clsx("relative h-5 w-9 rounded-full border transition", checked ? "border-accent/60 bg-accent/30" : "border-line bg-panel2")}>
        <span className={clsx("absolute top-0.5 h-3.5 w-3.5 rounded-full transition-all", checked ? "left-[18px] bg-accent" : "left-0.5 bg-zinc-500")} />
      </span>{label}
    </button>
  );
}

/* ---------- table ---------- */
export interface Column<T> { key: string; header: string; sortable?: boolean; className?: string; render: (row: T) => ReactNode }

export function DataTable<T>({ columns, rows, loading, rowKey, sort, order, onSort, empty, skeletonRows = 5 }: {
  columns: Column<T>[]; rows: T[]; loading?: boolean; rowKey: (r: T) => string | number;
  sort?: string; order?: "asc" | "desc"; onSort?: (key: string) => void; empty?: ReactNode; skeletonRows?: number;
}) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[720px] text-[13px]">
        <thead className="border-b border-line bg-panel2/40">
          <tr>
            {columns.map((c) => (
              <th key={c.key} className={clsx("th", c.className)}>
                {c.sortable && onSort ? (
                  <button className="inline-flex items-center gap-1 uppercase tracking-wider hover:text-zinc-200" onClick={() => onSort(c.key)}>
                    {c.header}
                    {sort === c.key && (order === "asc" ? <ChevronUp size={12} /> : <ChevronDown size={12} />)}
                  </button>
                ) : c.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-line">
          {loading
            ? Array.from({ length: skeletonRows }).map((_, i) => (
                <tr key={i}>{columns.map((c) => <td key={c.key} className="td"><Skeleton className="w-full max-w-[120px]" /></td>)}</tr>
              ))
            : rows.map((r) => (
                <tr key={rowKey(r)} className="transition hover:bg-panel2/50">
                  {columns.map((c) => <td key={c.key} className={clsx("td", c.className)}>{c.render(r)}</td>)}
                </tr>
              ))}
        </tbody>
      </table>
      {!loading && rows.length === 0 && empty}
    </div>
  );
}

export function Pagination({ page, pageSize, total, onPage }: { page: number; pageSize: number; total: number; onPage: (p: number) => void }) {
  const pages = Math.max(1, Math.ceil(total / pageSize));
  const from = total === 0 ? 0 : (page - 1) * pageSize + 1;
  return (
    <div className="flex items-center justify-between border-t border-line px-4 py-2.5 text-xs text-muted">
      <span>{from}–{Math.min(page * pageSize, total)} of {total}</span>
      <div className="flex items-center gap-1">
        <button className="btn-icon" disabled={page <= 1} onClick={() => onPage(page - 1)} aria-label="Previous page"><ChevronLeft size={16} /></button>
        <span className="px-2">Page {page} / {pages}</span>
        <button className="btn-icon" disabled={page >= pages} onClick={() => onPage(page + 1)} aria-label="Next page"><ChevronRight size={16} /></button>
      </div>
    </div>
  );
}
