import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Monitor, Play, RotateCw, Square, Trash2, Zap } from "lucide-react";
import { api } from "../api";
import { errText, useToast } from "../context";
import type { VM } from "../types";
import { ConfirmDialog, StatusBadge } from "./ui";

type ActionKey = "start" | "stop" | "force-stop" | "reboot" | "delete";

/** Compact action buttons + confirmations for one VM. */
export function VMActions({ vm, onDone, base = "" }: { vm: VM; onDone: () => void; base?: string }) {
  const toast = useToast();
  const nav = useNavigate();
  const [busy, setBusy] = useState(false);
  const [confirm, setConfirm] = useState<ActionKey | null>(null);

  const run = async (a: ActionKey) => {
    setBusy(true);
    try {
      if (a === "delete") await api(`/vms/${vm.id}`, { method: "DELETE" });
      else await api(`/vms/${vm.id}/${a}`, { method: "POST" });
      toast.push("success", a === "delete" ? `Deleted ${vm.name}` : `${a.replace("-", " ")} sent to ${vm.name}`);
      onDone();
    } catch (e) { toast.push("error", errText(e)); }
    finally { setBusy(false); }
  };

  const running = vm.status === "running";
  const locked = busy || vm.status === "creating";
  const text: Record<ActionKey, { t: string; m: string; l: string; danger?: boolean }> = {
    start: { t: "Start VM", m: `Start ${vm.name}?`, l: "Start" },
    stop: { t: "Shut down VM", m: `Send an ACPI shutdown signal to ${vm.name}?`, l: "Shut down" },
    "force-stop": { t: "Force stop VM", m: `Power off ${vm.name} immediately? Unsaved data in the guest may be lost.`, l: "Force stop", danger: true },
    reboot: { t: "Reboot VM", m: `Reboot ${vm.name}?`, l: "Reboot" },
    delete: { t: "Delete VM", m: `Permanently delete ${vm.name} and its disk? This cannot be undone.`, l: "Delete", danger: true },
  };

  return (
    <div className="flex items-center justify-end gap-0.5">
      {running && <button className="btn-icon" title="Console" disabled={locked} onClick={() => nav(`${base}/vms/${vm.id}/console`)}><Monitor size={15} /></button>}
      {!running && vm.status !== "stopping" && <button className="btn-icon hover:!text-emerald-400" title="Start" disabled={locked} onClick={() => run("start")}><Play size={15} /></button>}
      {running && <button className="btn-icon hover:!text-amber-400" title="Reboot" disabled={locked} onClick={() => setConfirm("reboot")}><RotateCw size={15} /></button>}
      {running && <button className="btn-icon hover:!text-red-400" title="Shut down" disabled={locked} onClick={() => setConfirm("stop")}><Square size={15} /></button>}
      {(running || vm.status === "stopping") && <button className="btn-icon hover:!text-red-400" title="Force stop" disabled={locked} onClick={() => setConfirm("force-stop")}><Zap size={15} /></button>}
      <button className="btn-icon hover:!text-red-400" title="Delete" disabled={locked} onClick={() => setConfirm("delete")}><Trash2 size={15} /></button>
      {confirm && (
        <ConfirmDialog open title={text[confirm].t} message={text[confirm].m} confirmLabel={text[confirm].l} danger={text[confirm].danger}
          onConfirm={() => run(confirm)} onClose={() => setConfirm(null)} />
      )}
    </div>
  );
}

export function VMCard({ vm, onDone, base, showOwner }: { vm: VM; onDone: () => void; base: string; showOwner?: boolean }) {
  return (
    <div className="card p-4 transition hover:border-zinc-700 hover:shadow-glow">
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <Link to={`${base}/vms/${vm.id}`} className="block truncate font-semibold text-zinc-50 hover:text-accent">{vm.name}</Link>
          <p className="truncate text-xs text-muted">#{vm.id} · {vm.os_name}{showOwner && vm.owner_name ? ` · ${vm.owner_name}` : ""}</p>
        </div>
        <StatusBadge status={vm.status} />
      </div>
      <dl className="mt-3 grid grid-cols-3 gap-2 text-center text-xs">
        {[["CPU", `${vm.cpu} vCPU`], ["RAM", vm.ram_mb >= 1024 ? `${+(vm.ram_mb / 1024).toFixed(1)} GB` : `${vm.ram_mb} MB`], ["Disk", `${vm.disk_gb} GB`]].map(([k, v]) => (
          <div key={k} className="rounded-lg bg-panel2 py-1.5"><dt className="text-[10px] uppercase tracking-wider text-muted">{k}</dt><dd className="font-medium text-zinc-100">{v}</dd></div>
        ))}
      </dl>
      <div className="mt-3 flex items-center justify-between">
        <span className="font-mono text-xs text-muted">{vm.ip_address ?? "No IP"}</span>
        <VMActions vm={vm} onDone={onDone} base={base} />
      </div>
    </div>
  );
}
