export type VMStatus = "running" | "stopped" | "paused" | "stopping" | "error" | "creating";

export interface User {
  id: number; email: string; username: string; role: "user" | "admin"; is_active: boolean;
  max_vms: number | null; created_at: string; last_login: string | null; vm_count: number;
}
export interface VM {
  id: number; name: string; owner_id: number; owner_name?: string | null; os_name: string; status: VMStatus;
  cpu: number; ram_mb: number; disk_gb: number; ip_address: string | null; mac: string | null; network: string;
  created_at: string; started_at: string | null; has_console: boolean; uuid?: string; libvirt_name?: string | null;
}
export interface Page<T> { items: T[]; total: number; page: number; page_size: number }
export interface Summary { total: number; running: number; stopped: number; total_ram_mb: number; total_disk_gb: number; total_cpu: number }
export interface Activity { id: number; action: string; detail: string; level: string; vm_id: number | null; created_at: string; user?: string | null; ip?: string | null }
export interface Template {
  id: number; name: string; os_family: string; version: string; min_cpu: number; min_ram_mb: number; min_disk_gb: number;
  supports_credentials?: boolean; image_path?: string | null; iso_path?: string | null; is_active?: boolean; file_ok?: boolean;
}
export interface Metrics {
  status: VMStatus; cpu_percent: number; mem_used_mb: number; mem_total_mb: number; disk_used_gb: number; disk_total_gb: number;
  net_rx_bytes: number; net_tx_bytes: number; uptime_seconds: number;
}
export interface HostInfo {
  cpu_percent: number; cpu_count: number; mem_percent: number; mem_used_mb: number; mem_total_mb: number;
  disk_percent: number; disk_used_gb: number; disk_total_gb: number; load: number[]; boot_time: number;
}
export interface SystemStatus {
  kvm: { ok: boolean; detail: string }; libvirt: { ok: boolean; detail: string }; database: { ok: boolean; detail: string };
  host: HostInfo; health: { cpu: string; memory: string; disk: string };
}
export interface PanelSettings {
  panel_name: string; allow_registration: boolean; default_max_vms: number; max_cpu_per_vm: number;
  max_ram_mb_per_vm: number; max_disk_gb_per_vm: number; refresh_interval_seconds: number;
}
