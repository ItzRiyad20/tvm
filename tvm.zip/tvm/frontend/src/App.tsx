import { Navigate, Outlet, Route, Routes } from "react-router-dom";
import { useAuth } from "./context";
import Layout from "./components/Layout";
import { Spinner } from "./components/ui";
import LoginPage from "./pages/LoginPage";
import UserDashboard from "./pages/UserDashboard";
import VMListPage from "./pages/VMListPage";
import VMDetailPage from "./pages/VMDetailPage";
import CreateVMPage from "./pages/CreateVMPage";
import ConsolePage from "./pages/ConsolePage";
import ProfilePage from "./pages/ProfilePage";
import AdminDashboard from "./pages/AdminDashboard";
import AdminUsers from "./pages/AdminUsers";
import AdminTemplates from "./pages/AdminTemplates";
import AdminSettings from "./pages/AdminSettings";
import AdminMonitoring from "./pages/AdminMonitoring";
import AdminLogs from "./pages/AdminLogs";

function RequireAuth() {
  const { user, loading } = useAuth();
  if (loading) return <div className="flex min-h-screen items-center justify-center text-muted"><Spinner size={24} /></div>;
  return user ? <Layout /> : <Navigate to="/login" replace />;
}

function RequireAdmin() {
  const { user } = useAuth();
  return user?.role === "admin" ? <Outlet /> : <Navigate to="/" replace />;
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route element={<RequireAuth />}>
        <Route index element={<UserDashboard />} />
        <Route path="vms" element={<VMListPage scope="mine" />} />
        <Route path="vms/new" element={<CreateVMPage />} />
        <Route path="vms/:id" element={<VMDetailPage />} />
        <Route path="vms/:id/console" element={<ConsolePage />} />
        <Route path="profile" element={<ProfilePage />} />
        <Route path="admin" element={<RequireAdmin />}>
          <Route index element={<AdminDashboard />} />
          <Route path="vms" element={<VMListPage scope="all" />} />
          <Route path="vms/new" element={<CreateVMPage admin />} />
          <Route path="vms/:id" element={<VMDetailPage admin />} />
          <Route path="vms/:id/console" element={<ConsolePage admin />} />
          <Route path="users" element={<AdminUsers />} />
          <Route path="settings" element={<AdminSettings />} />
          <Route path="templates" element={<AdminTemplates />} />
          <Route path="monitoring" element={<AdminMonitoring />} />
          <Route path="logs" element={<AdminLogs />} />
        </Route>
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
