import { createContext, ReactNode, useCallback, useContext, useEffect, useState } from "react";
import { AlertTriangle, CheckCircle2, Info, X } from "lucide-react";
import { api, ApiError } from "./api";
import type { User } from "./types";

/* ---------------- Toasts ---------------- */
type ToastKind = "success" | "error" | "info";
interface Toast { id: number; kind: ToastKind; text: string }
const ToastCtx = createContext<{ push: (kind: ToastKind, text: string) => void }>({ push: () => {} });
export const useToast = () => useContext(ToastCtx);

export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<Toast[]>([]);
  const push = useCallback((kind: ToastKind, text: string) => {
    const id = Date.now() + Math.random();
    setItems((x) => [...x, { id, kind, text }]);
    setTimeout(() => setItems((x) => x.filter((t) => t.id !== id)), kind === "error" ? 7000 : 4000);
  }, []);
  const icon = { success: <CheckCircle2 size={16} className="text-emerald-400" />, error: <AlertTriangle size={16} className="text-red-400" />, info: <Info size={16} className="text-cyan-400" /> };
  return (
    <ToastCtx.Provider value={{ push }}>
      {children}
      <div className="pointer-events-none fixed bottom-4 right-4 z-[100] flex w-[min(92vw,360px)] flex-col gap-2">
        {items.map((t) => (
          <div key={t.id} className="pointer-events-auto flex items-start gap-2.5 rounded-lg border border-line bg-panel2 p-3 shadow-xl">
            <span className="mt-0.5">{icon[t.kind]}</span>
            <p className="flex-1 text-[13px] text-zinc-200">{t.text}</p>
            <button className="text-muted hover:text-zinc-100" onClick={() => setItems((x) => x.filter((i) => i.id !== t.id))}><X size={14} /></button>
          </div>
        ))}
      </div>
    </ToastCtx.Provider>
  );
}

export const errText = (e: unknown) => (e instanceof ApiError || e instanceof Error ? e.message : "Something went wrong");

/* ---------------- Auth ---------------- */
interface AuthState {
  user: User | null; loading: boolean; panelName: string;
  login: (identifier: string, password: string) => Promise<void>;
  register: (email: string, username: string, password: string) => Promise<void>;
  logout: () => Promise<void>; refresh: () => Promise<void>;
}
const AuthCtx = createContext<AuthState>(null as unknown as AuthState);
export const useAuth = () => useContext(AuthCtx);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [panelName] = useState("TVM Panel");

  const refresh = useCallback(async () => {
    try { setUser(await api<User>("/auth/me")); } catch { setUser(null); }
  }, []);
  useEffect(() => { refresh().finally(() => setLoading(false)); }, [refresh]);

  const value: AuthState = {
    user, loading, panelName, refresh,
    login: async (identifier, password) => setUser(await api<User>("/auth/login", { method: "POST", body: { identifier, password } })),
    register: async (email, username, password) => setUser(await api<User>("/auth/register", { method: "POST", body: { email, username, password } })),
    logout: async () => { try { await api("/auth/logout", { method: "POST" }); } finally { setUser(null); } },
  };
  return <AuthCtx.Provider value={value}>{children}</AuthCtx.Provider>;
}
