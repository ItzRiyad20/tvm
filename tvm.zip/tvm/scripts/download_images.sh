#!/usr/bin/env bash
# Downloads the official Ubuntu 24.04 cloud image and registers it as an OS template.
# Usage: sudo bash scripts/download_images.sh
set -euo pipefail
IMG_DIR=/var/lib/tvm/images
APP=/opt/tvm-panel/backend
URL="https://cloud-images.ubuntu.com/noble/current/noble-server-cloudimg-amd64.img"
mkdir -p "$IMG_DIR"
curl -fL --progress-bar -o "$IMG_DIR/ubuntu-24.04.img" "$URL"
chmod 644 "$IMG_DIR/ubuntu-24.04.img"
cd "$APP"
sudo -u tvm venv/bin/python -m app.cli add-template --name "Ubuntu 24.04 LTS" --version 24.04 \
  --image "$IMG_DIR/ubuntu-24.04.img" --min-cpu 1 --min-ram 1024 --min-disk 10
echo "Template added. More images: download any qcow2 cloud image, or an ISO, to $IMG_DIR and register it in Admin > OS Templates."
