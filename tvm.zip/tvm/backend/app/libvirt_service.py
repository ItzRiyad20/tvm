"""libvirt / KVM integration. All privileged virtualization work lives here."""
import os
import re
import shutil
import subprocess
import threading
import time
import uuid as uuidlib
from xml.etree import ElementTree as ET
from xml.sax.saxutils import escape

try:
    import libvirt  # type: ignore
except ImportError:  # allows importing the app on machines without libvirt
    libvirt = None

from .config import settings


class LibvirtError(Exception):
    pass


_conn = None
_lock = threading.Lock()
_last_cpu: dict[str, tuple[float, int]] = {}  # uuid -> (wall time, cpu ns)


def connect():
    global _conn
    if libvirt is None:
        raise LibvirtError("libvirt-python is not installed")
    with _lock:
        try:
            if _conn is not None and _conn.isAlive():
                return _conn
        except libvirt.libvirtError:
            _conn = None
        try:
            _conn = libvirt.open(settings.libvirt_uri)
        except libvirt.libvirtError as e:
            _conn = None
            raise LibvirtError(f"Cannot connect to libvirt: {e}") from e
        return _conn


def is_available() -> bool:
    try:
        connect()
        return True
    except LibvirtError:
        return False


def _lookup(name: str):
    conn = connect()
    try:
        return conn.lookupByName(name)
    except libvirt.libvirtError:
        return None


_STATE = {1: "running", 2: "running", 3: "paused", 4: "stopping", 5: "stopped", 6: "error", 7: "paused"}


def state_of(dom) -> str:
    return _STATE.get(dom.state()[0], "stopped")


def _run(cmd: list[str]) -> None:
    try:
        subprocess.run(cmd, check=True, capture_output=True, text=True, timeout=300)
    except subprocess.CalledProcessError as e:
        raise LibvirtError(f"{cmd[0]} failed: {e.stderr.strip()[:300]}") from e
    except FileNotFoundError as e:
        raise LibvirtError(f"{cmd[0]} is not installed on the host") from e


def _random_mac() -> str:
    import random
    return "52:54:00:%02x:%02x:%02x" % (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))


def disk_path(libvirt_name: str) -> str:
    return os.path.join(settings.storage_dir, f"{libvirt_name}.qcow2")


def seed_path(libvirt_name: str) -> str:
    return os.path.join(settings.storage_dir, f"{libvirt_name}-seed.iso")


def build_xml(*, name: str, vm_uuid: str, cpu: int, ram_mb: int, disk: str, iso: str | None,
              seed: str | None, mac: str) -> str:
    if settings.libvirt_bridge:
        net = f"<interface type='bridge'><source bridge='{escape(settings.libvirt_bridge)}'/><mac address='{mac}'/><model type='virtio'/></interface>"
    else:
        net = f"<interface type='network'><source network='{escape(settings.libvirt_network)}'/><mac address='{mac}'/><model type='virtio'/></interface>"
    cdrom = ""
    if iso:
        cdrom += f"<disk type='file' device='cdrom'><driver name='qemu' type='raw'/><source file='{escape(iso)}'/><target dev='sda' bus='sata'/><readonly/><boot order='1'/></disk>"
    if seed:
        cdrom += f"<disk type='file' device='cdrom'><driver name='qemu' type='raw'/><source file='{escape(seed)}'/><target dev='sdb' bus='sata'/><readonly/></disk>"
    disk_boot = "<boot order='2'/>" if iso else "<boot order='1'/>"
    return f"""<domain type='kvm'>
  <name>{name}</name><uuid>{vm_uuid}</uuid>
  <memory unit='MiB'>{ram_mb}</memory><vcpu placement='static'>{cpu}</vcpu>
  <os><type arch='x86_64' machine='q35'>hvm</type></os>
  <features><acpi/><apic/></features>
  <cpu mode='host-passthrough'/>
  <clock offset='utc'/>
  <on_poweroff>destroy</on_poweroff><on_reboot>restart</on_reboot><on_crash>destroy</on_crash>
  <devices>
    <emulator>/usr/bin/qemu-system-x86_64</emulator>
    <disk type='file' device='disk'><driver name='qemu' type='qcow2'/><source file='{escape(disk)}'/><target dev='vda' bus='virtio'/>{disk_boot}</disk>
    {cdrom}
    {net}
    <graphics type='vnc' port='-1' autoport='yes' listen='127.0.0.1'><listen type='address' address='127.0.0.1'/></graphics>
    <video><model type='vga'/></video>
    <memballoon model='virtio'/>
    <console type='pty'/>
  </devices>
</domain>"""


def create_vm(*, libvirt_name: str, cpu: int, ram_mb: int, disk_gb: int, image_path: str | None,
              iso_path: str | None, root_password: str | None, ssh_key: str | None) -> dict:
    """Create disk + domain and start it. Returns {uuid, mac}. Cleans up after itself on failure."""
    conn = connect()
    os.makedirs(settings.storage_dir, exist_ok=True)
    dpath, spath = disk_path(libvirt_name), None
    vm_uuid, mac = str(uuidlib.uuid4()), _random_mac()
    try:
        if image_path:
            if not os.path.isfile(image_path):
                raise LibvirtError("Template image file is missing on the host")
            _run(["qemu-img", "create", "-f", "qcow2", "-b", image_path, "-F", "qcow2", dpath, f"{disk_gb}G"])
            if root_password or ssh_key:
                spath = _make_seed(libvirt_name, root_password, ssh_key)
        else:
            if not iso_path or not os.path.isfile(iso_path):
                raise LibvirtError("Template ISO file is missing on the host")
            _run(["qemu-img", "create", "-f", "qcow2", dpath, f"{disk_gb}G"])
        xml = build_xml(name=libvirt_name, vm_uuid=vm_uuid, cpu=cpu, ram_mb=ram_mb, disk=dpath,
                        iso=None if image_path else iso_path, seed=spath, mac=mac)
        try:
            dom = conn.defineXML(xml)
            dom.create()
        except libvirt.libvirtError as e:
            raise LibvirtError(f"Could not start VM: {e}") from e
        return {"uuid": vm_uuid, "mac": mac}
    except Exception:
        _cleanup_files(libvirt_name)
        d = _lookup(libvirt_name)
        if d is not None:
            _force_remove(d)
        raise


def _make_seed(libvirt_name: str, password: str | None, ssh_key: str | None) -> str:
    tool = shutil.which("cloud-localds")
    if not tool:
        raise LibvirtError("cloud-localds missing on host (install cloud-image-utils) - needed for password/SSH key injection")
    lines = ["#cloud-config", "ssh_pwauth: true", "disable_root: false"]
    if password:
        # chpasswd takes list entries; reject chars that could break YAML/format
        if not re.fullmatch(r"[A-Za-z0-9!@#%^*_+=.,-]{8,64}", password):
            raise LibvirtError("Password must be 8-64 chars: letters, digits and !@#%^*_+=.,-")
        lines += ["chpasswd:", "  expire: false", "  list: |", f"    root:{password}"]
    if ssh_key:
        if not re.fullmatch(r"(ssh-(rsa|ed25519)|ecdsa-sha2-nistp\d+) [A-Za-z0-9+/=]+( [^\r\n]{0,100})?", ssh_key.strip()):
            raise LibvirtError("Invalid SSH public key")
        lines += ["ssh_authorized_keys:", f"  - {ssh_key.strip()}"]
    lines += [f"hostname: {libvirt_name}"]
    sp = seed_path(libvirt_name)
    ud = sp + ".user-data"
    with open(ud, "w") as f:
        f.write("\n".join(lines) + "\n")
    os.chmod(ud, 0o600)
    try:
        _run([tool, sp, ud])
    finally:
        try:
            os.remove(ud)
        except OSError:
            pass
    return sp


def _cleanup_files(libvirt_name: str) -> None:
    for p in (disk_path(libvirt_name), seed_path(libvirt_name)):
        try:
            os.remove(p)
        except OSError:
            pass


def _force_remove(dom) -> None:
    try:
        if dom.isActive():
            dom.destroy()
    except libvirt.libvirtError:
        pass
    try:
        dom.undefineFlags(libvirt.VIR_DOMAIN_UNDEFINE_NVRAM)
    except libvirt.libvirtError:
        try:
            dom.undefine()
        except libvirt.libvirtError:
            pass


def _need(name: str):
    dom = _lookup(name)
    if dom is None:
        raise LibvirtError("VM is not defined on the hypervisor")
    return dom


def start(name: str) -> None:
    dom = _need(name)
    try:
        if not dom.isActive():
            dom.create()
    except libvirt.libvirtError as e:
        raise LibvirtError(f"Start failed: {e}") from e


def stop(name: str, force: bool = False) -> None:
    dom = _need(name)
    try:
        if dom.isActive():
            dom.destroy() if force else dom.shutdown()
    except libvirt.libvirtError as e:
        raise LibvirtError(f"Stop failed: {e}") from e


def reboot(name: str) -> None:
    dom = _need(name)
    try:
        if not dom.isActive():
            raise LibvirtError("VM is not running")
        dom.reboot(0)
    except libvirt.libvirtError as e:
        raise LibvirtError(f"Reboot failed: {e}") from e


def delete(name: str) -> None:
    dom = _lookup(name)
    if dom is not None:
        _force_remove(dom)
    _cleanup_files(name)


def runtime_info(name: str) -> dict:
    """Current status, IP and VNC port for a domain; status 'stopped' if it is not defined."""
    dom = _lookup(name)
    if dom is None:
        return {"status": "error", "ip": None, "vnc_port": None, "defined": False}
    status = state_of(dom)
    ip = vnc = None
    if dom.isActive():
        for src in (getattr(libvirt, "VIR_DOMAIN_INTERFACE_ADDRESSES_SRC_LEASE", 0),
                    getattr(libvirt, "VIR_DOMAIN_INTERFACE_ADDRESSES_SRC_ARP", 2)):
            try:
                for iface in dom.interfaceAddresses(src).values():
                    for a in iface.get("addrs") or []:
                        if a["type"] == libvirt.VIR_IP_ADDR_TYPE_IPV4:
                            ip = a["addr"]
                            break
                    if ip:
                        break
            except libvirt.libvirtError:
                pass
            if ip:
                break
        try:
            g = ET.fromstring(dom.XMLDesc(0)).find("./devices/graphics[@type='vnc']")
            if g is not None and g.get("port", "-1") != "-1":
                vnc = int(g.get("port"))
        except (libvirt.libvirtError, ET.ParseError, ValueError):
            pass
    return {"status": status, "ip": ip, "vnc_port": vnc, "defined": True}


def metrics(name: str) -> dict:
    dom = _need(name)
    out = {"status": state_of(dom), "cpu_percent": 0.0, "mem_used_mb": 0, "mem_total_mb": 0,
           "disk_used_gb": 0.0, "disk_total_gb": 0.0, "net_rx_bytes": 0, "net_tx_bytes": 0}
    try:
        st, maxmem, _mem, vcpus, cputime = dom.info()
        out["mem_total_mb"] = int(maxmem / 1024)
        uid = dom.UUIDString()
        now = time.time()
        if st == 1:
            prev = _last_cpu.get(uid)
            if prev and now > prev[0]:
                out["cpu_percent"] = round(max(0.0, min(100.0, (cputime - prev[1]) / ((now - prev[0]) * 1e9 * max(vcpus, 1)) * 100)), 1)
            _last_cpu[uid] = (now, cputime)
            stats = dom.memoryStats()
            if "available" in stats and "unused" in stats:
                out["mem_used_mb"] = int((stats["available"] - stats["unused"]) / 1024)
            elif "rss" in stats:
                out["mem_used_mb"] = int(stats["rss"] / 1024)
        else:
            _last_cpu.pop(uid, None)
        root = ET.fromstring(dom.XMLDesc(0))
        try:
            cap, alloc, _phys = dom.blockInfo("vda")
            out["disk_total_gb"] = round(cap / 1024 ** 3, 1)
            out["disk_used_gb"] = round(alloc / 1024 ** 3, 2)
        except libvirt.libvirtError:
            pass
        if st == 1:
            t = root.find("./devices/interface/target")
            if t is not None:
                try:
                    s = dom.interfaceStats(t.get("dev"))
                    out["net_rx_bytes"], out["net_tx_bytes"] = s[0], s[4]
                except libvirt.libvirtError:
                    pass
    except libvirt.libvirtError as e:
        raise LibvirtError(str(e)) from e
    return out


def host_versions() -> dict:
    conn = connect()
    try:
        return {"libvirt": _ver(conn.getLibVersion()), "qemu": _ver(conn.getVersion()),
                "hostname": conn.getHostname()}
    except libvirt.libvirtError:
        return {}


def _ver(n: int) -> str:
    return f"{n // 1000000}.{(n // 1000) % 1000}.{n % 1000}"
