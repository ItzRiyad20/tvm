import hashlib
import secrets
import time
from collections import defaultdict, deque
from datetime import datetime, timedelta, timezone

from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError, InvalidHashError
from fastapi import Depends, HTTPException
from sqlalchemy.orm import Session
from starlette.requests import HTTPConnection

from .config import settings
from .db import get_db
from .models import SessionToken, User

COOKIE = "tvm_session"
_ph = PasswordHasher()


def hash_password(pw: str) -> str:
    return _ph.hash(pw)


def verify_password(pw: str, hashed: str) -> bool:
    try:
        return _ph.verify(hashed, pw)
    except (VerifyMismatchError, InvalidHashError):
        return False


def _hash_token(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def create_session(db: Session, user: User) -> str:
    token = secrets.token_urlsafe(32)
    db.add(SessionToken(
        token_hash=_hash_token(token),
        user_id=user.id,
        expires_at=datetime.now(timezone.utc) + timedelta(hours=settings.session_hours),
    ))
    db.commit()
    return token


def destroy_session(db: Session, token: str) -> None:
    s = db.get(SessionToken, _hash_token(token))
    if s:
        db.delete(s)
        db.commit()


def user_from_token(db: Session, token: str | None) -> User | None:
    if not token:
        return None
    s = db.get(SessionToken, _hash_token(token))
    if not s or s.expires_at < datetime.now(timezone.utc):
        return None
    user = db.get(User, s.user_id)
    if not user or not user.is_active:
        return None
    return user


def get_current_user(conn: HTTPConnection, db: Session = Depends(get_db)) -> User:
    user = user_from_token(db, conn.cookies.get(COOKIE))
    if not user:
        raise HTTPException(401, "Not authenticated")
    return user


def require_admin(user: User = Depends(get_current_user)) -> User:
    if user.role != "admin":
        raise HTTPException(403, "Administrator access required")
    return user


# Simple in-memory login throttle (the service runs as a single worker).
_attempts: dict[str, deque] = defaultdict(deque)


def throttle_login(key: str, limit: int = 10, window: int = 900) -> None:
    now = time.time()
    q = _attempts[key]
    while q and q[0] < now - window:
        q.popleft()
    if len(q) >= limit:
        raise HTTPException(429, "Too many login attempts. Try again later.")


def record_failed_login(key: str) -> None:
    _attempts[key].append(time.time())


def clear_login_failures(key: str) -> None:
    _attempts.pop(key, None)
