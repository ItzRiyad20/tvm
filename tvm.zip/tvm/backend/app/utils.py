import json

from fastapi import Request
from sqlalchemy.orm import Session

from .models import ActivityLog, Setting

DEFAULTS: dict = {
    "panel_name": "TVM Panel",
    "allow_registration": False,
    "default_max_vms": 3,
    "max_cpu_per_vm": 8,
    "max_ram_mb_per_vm": 16384,
    "max_disk_gb_per_vm": 500,
    "refresh_interval_seconds": 10,
}


def get_settings(db: Session) -> dict:
    out = dict(DEFAULTS)
    for row in db.query(Setting).all():
        if row.key in DEFAULTS:
            try:
                out[row.key] = json.loads(row.value)
            except ValueError:
                pass
    return out


def set_setting(db: Session, key: str, value) -> None:
    row = db.get(Setting, key)
    if row:
        row.value = json.dumps(value)
    else:
        db.add(Setting(key=key, value=json.dumps(value)))


def client_ip(request: Request | None) -> str | None:
    if request is None:
        return None
    fwd = request.headers.get("x-forwarded-for")
    if fwd:
        return fwd.split(",")[0].strip()
    return request.client.host if request.client else None


def log_activity(db: Session, user_id: int | None, action: str, detail: str = "",
                 vm_id: int | None = None, level: str = "info", request: Request | None = None) -> None:
    db.add(ActivityLog(user_id=user_id, vm_id=vm_id, action=action, detail=detail,
                       level=level, ip=client_ip(request)))
    db.commit()
