from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    database_url: str
    secret_key: str
    libvirt_uri: str = "qemu:///system"
    storage_dir: str = "/var/lib/tvm/disks"
    libvirt_network: str = "default"
    libvirt_bridge: str = ""
    session_hours: int = 168
    cookie_secure: bool = False


settings = Settings()  # type: ignore[call-arg]
