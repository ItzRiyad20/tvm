from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from .routers import admin, auth, vms

app = FastAPI(title="TVM Panel API", docs_url=None, redoc_url=None, openapi_url=None)

UNSAFE = {"POST", "PUT", "PATCH", "DELETE"}


@app.middleware("http")
async def csrf_and_headers(request: Request, call_next):
    # State-changing API calls must carry a custom header, which browsers will not
    # send cross-site without a CORS preflight (and no CORS is enabled).
    if request.method in UNSAFE and request.url.path.startswith("/api") and request.headers.get("x-tvm-csrf") != "1":
        return JSONResponse({"detail": "Missing CSRF header"}, status_code=403)
    resp = await call_next(request)
    resp.headers.setdefault("X-Content-Type-Options", "nosniff")
    resp.headers.setdefault("X-Frame-Options", "DENY")
    resp.headers.setdefault("Cache-Control", "no-store")
    return resp


app.include_router(auth.router)
app.include_router(vms.router)
app.include_router(admin.router)
