import re
from datetime import datetime

from pydantic import BaseModel, EmailStr, Field, field_validator

NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 _-]{1,62}$")
USERNAME_RE = re.compile(r"^[A-Za-z0-9_.-]{3,32}$")


class LoginIn(BaseModel):
    identifier: str = Field(min_length=1, max_length=255)
    password: str = Field(min_length=1, max_length=256)


class RegisterIn(BaseModel):
    email: EmailStr
    username: str
    password: str = Field(min_length=8, max_length=256)

    @field_validator("username")
    @classmethod
    def _u(cls, v: str) -> str:
        if not USERNAME_RE.match(v):
            raise ValueError("Username must be 3-32 chars (letters, digits, _ . -)")
        return v


class ProfileUpdate(BaseModel):
    email: EmailStr | None = None
    current_password: str | None = None
    new_password: str | None = Field(default=None, min_length=8, max_length=256)


class UserOut(BaseModel):
    id: int
    email: str
    username: str
    role: str
    is_active: bool
    max_vms: int | None
    created_at: datetime
    last_login: datetime | None
    vm_count: int = 0

    model_config = {"from_attributes": True}


class AdminUserUpdate(BaseModel):
    role: str | None = Field(default=None, pattern="^(user|admin)$")
    is_active: bool | None = None
    max_vms: int | None = Field(default=None, ge=0, le=1000)
    clear_max_vms: bool = False
    new_password: str | None = Field(default=None, min_length=8, max_length=256)


class AdminUserCreate(BaseModel):
    email: EmailStr
    username: str
    password: str = Field(min_length=8, max_length=256)
    role: str = Field(default="user", pattern="^(user|admin)$")


class VMCreate(BaseModel):
    name: str
    template_id: int
    cpu: int = Field(ge=1, le=128)
    ram_mb: int = Field(ge=256, le=1048576)
    disk_gb: int = Field(ge=1, le=10000)
    root_password: str | None = None
    ssh_key: str | None = None
    owner_id: int | None = None  # admins only

    @field_validator("name")
    @classmethod
    def _n(cls, v: str) -> str:
        v = v.strip()
        if not NAME_RE.match(v):
            raise ValueError("Name must be 2-63 chars: letters, digits, space, _ and -")
        return v


class TemplateIn(BaseModel):
    name: str = Field(min_length=2, max_length=128)
    os_family: str = Field(default="linux", pattern="^(linux|windows|bsd|other)$")
    version: str = Field(default="", max_length=32)
    image_path: str | None = None
    iso_path: str | None = None
    min_cpu: int = Field(default=1, ge=1, le=128)
    min_ram_mb: int = Field(default=512, ge=128)
    min_disk_gb: int = Field(default=10, ge=1)
    is_active: bool = True


class SettingsIn(BaseModel):
    panel_name: str | None = Field(default=None, min_length=1, max_length=64)
    allow_registration: bool | None = None
    default_max_vms: int | None = Field(default=None, ge=0, le=1000)
    max_cpu_per_vm: int | None = Field(default=None, ge=1, le=128)
    max_ram_mb_per_vm: int | None = Field(default=None, ge=256)
    max_disk_gb_per_vm: int | None = Field(default=None, ge=1)
    refresh_interval_seconds: int | None = Field(default=None, ge=0, le=3600)
