"""Admin CLI.  Usage (from /opt/tvm-panel/backend):
    venv/bin/python -m app.cli create-admin
    venv/bin/python -m app.cli add-template --name "Ubuntu 24.04" --image /var/lib/tvm/images/x.img --version 24.04
"""
import argparse
import getpass
import sys

from .db import SessionLocal
from .models import OSTemplate, User
from .schemas import USERNAME_RE
from .security import hash_password


def create_admin(args) -> int:
    email = (args.email or input("Admin email: ")).strip().lower()
    username = (args.username or input("Admin username: ")).strip()
    if not USERNAME_RE.match(username):
        print("Username must be 3-32 chars (letters, digits, _ . -)")
        return 1
    pw = getpass.getpass("Password (min 8 chars): ")
    if len(pw) < 8 or pw != getpass.getpass("Repeat password: "):
        print("Passwords must match and be at least 8 characters")
        return 1
    with SessionLocal() as db:
        if db.query(User).filter((User.email == email) | (User.username == username)).first():
            print("A user with that email or username already exists")
            return 1
        db.add(User(email=email, username=username, password_hash=hash_password(pw), role="admin"))
        db.commit()
    print(f"Admin '{username}' created.")
    return 0


def add_template(args) -> int:
    if not args.image and not args.iso:
        print("--image or --iso is required")
        return 1
    with SessionLocal() as db:
        db.add(OSTemplate(name=args.name, os_family=args.family, version=args.version, image_path=args.image,
                          iso_path=args.iso, min_cpu=args.min_cpu, min_ram_mb=args.min_ram, min_disk_gb=args.min_disk))
        db.commit()
    print(f"Template '{args.name}' added.")
    return 0


def main() -> int:
    p = argparse.ArgumentParser(prog="tvm")
    sub = p.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("create-admin")
    a.add_argument("--email")
    a.add_argument("--username")
    a.set_defaults(fn=create_admin)
    t = sub.add_parser("add-template")
    t.add_argument("--name", required=True)
    t.add_argument("--family", default="linux")
    t.add_argument("--version", default="")
    t.add_argument("--image")
    t.add_argument("--iso")
    t.add_argument("--min-cpu", type=int, default=1)
    t.add_argument("--min-ram", type=int, default=512)
    t.add_argument("--min-disk", type=int, default=10)
    t.set_defaults(fn=add_template)
    args = p.parse_args()
    return args.fn(args)


if __name__ == "__main__":
    sys.exit(main())
