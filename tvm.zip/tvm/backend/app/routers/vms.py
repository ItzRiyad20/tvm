import asyncio
import uuid as uuidlib
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Query, Request, WebSocket
from sqlalchemy import String, cast, func, or_
from sqlalchemy.orm import Session

from .. import libvirt_service as lv
from ..db import SessionLocal, get_db
from ..models import ActivityLog, OSTemplate, User, VM
from ..schemas import VMCreate
from ..security import COOKIE, get_current_user, user_from_token
from ..utils import get_settings, log_activity

router = APIRouter(prefix="/api", tags=["vms"])

SORTS = {"name": VM.name, "os": VM.os_name, "status": VM.status, "cpu": VM.cpu, "ram": VM.ram_mb,
         "disk": VM.disk_gb, "created": VM.created_at, "id": VM.id}


def serialize(vm: VM, owner_name: str | None = None) -> dict:
    return {"id": vm.id, "name": vm.name, "owner_id": vm.owner_id, "owner_name": owner_name,
            "os_name": vm.os_name, "status": vm.status, "cpu": vm.cpu, "ram_mb": vm.ram_mb,
            "disk_gb": vm.disk_gb, "ip_address": vm.ip_address, "mac": vm.mac, "network": vm.network,
            "created_at": vm.created_at, "started_at": vm.started_at,
            "has_console": vm.status == "running"}


def sync_vm(db: Session, vm: VM) -> None:
    """Refresh a VM row from the hypervisor. If libvirt is unreachable the stored state is kept."""
    if vm.status == "creating":
        return
    try:
        info = lv.runtime_info(vm.libvirt_name)
    except lv.LibvirtError:
        return
    status = info["status"]
    if status != vm.status:
        if status == "running" and not vm.started_at:
            vm.started_at = datetime.now(timezone.utc)
        if status in ("stopped", "error"):
            vm.started_at = None
        vm.status = status
    if status == "running":
        vm.ip_address = info["ip"] or vm.ip_address
        if vm.started_at is None:
            vm.started_at = datetime.now(timezone.utc)
    else:
        vm.ip_address = vm.ip_address if status == "stopping" else None
    db.commit()


def get_vm_or_404(db: Session, vm_id: int, user: User) -> VM:
    vm = db.get(VM, vm_id)
    # 404 (not 403) for other users' VMs so existence isn't leaked
    if not vm or (vm.owner_id != user.id and user.role != "admin"):
        raise HTTPException(404, "Virtual machine not found")
    return vm


def _scope_query(db: Session, user: User, scope: str):
    q = db.query(VM, User.username).join(User, User.id == VM.owner_id)
    if scope == "all":
        if user.role != "admin":
            raise HTTPException(403, "Administrator access required")
    else:
        q = q.filter(VM.owner_id == user.id)
    return q


@router.get("/vms/summary")
def summary(scope: str = "mine", user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    vms = [r[0] for r in _scope_query(db, user, scope).all()]
    for v in vms:
        sync_vm(db, v)
    return {"total": len(vms),
            "running": sum(v.status == "running" for v in vms),
            "stopped": sum(v.status in ("stopped", "paused") for v in vms),
            "total_ram_mb": sum(v.ram_mb for v in vms),
            "total_disk_gb": sum(v.disk_gb for v in vms),
            "total_cpu": sum(v.cpu for v in vms)}


@router.get("/vms")
def list_vms(scope: str = "mine", search: str = "", status: str = "", sort: str = "created", order: str = "desc",
             page: int = Query(1, ge=1), page_size: int = Query(10, ge=1, le=100),
             user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    q = _scope_query(db, user, scope)
    if status:
        q = q.filter(VM.status.in_(["stopped", "paused"]) if status == "stopped" else VM.status == status)
    if search.strip():
        like = f"%{search.strip()}%"
        q = q.filter(or_(VM.name.ilike(like), VM.os_name.ilike(like), VM.ip_address.ilike(like),
                         cast(VM.id, String) == search.strip().lstrip("#"), User.username.ilike(like)))
    total = q.count()
    col = SORTS.get(sort, VM.created_at)
    q = q.order_by(col.asc() if order == "asc" else col.desc(), VM.id.desc())
    rows = q.offset((page - 1) * page_size).limit(page_size).all()
    for vm, _ in rows:
        sync_vm(db, vm)
    return {"items": [serialize(vm, uname) for vm, uname in rows], "total": total, "page": page, "page_size": page_size}


@router.post("/vms", status_code=201)
def create_vm(body: VMCreate, request: Request, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    s = get_settings(db)
    owner = user
    if body.owner_id and body.owner_id != user.id:
        if user.role != "admin":
            raise HTTPException(403, "Only administrators can create VMs for other users")
        owner = db.get(User, body.owner_id)
        if not owner:
            raise HTTPException(404, "Owner not found")
    tpl = db.get(OSTemplate, body.template_id)
    if not tpl or not tpl.is_active:
        raise HTTPException(400, "Unknown or inactive OS template")
    if user.role != "admin":
        if body.cpu > s["max_cpu_per_vm"] or body.ram_mb > s["max_ram_mb_per_vm"] or body.disk_gb > s["max_disk_gb_per_vm"]:
            raise HTTPException(400, "Requested resources exceed the per-VM limits")
        quota = owner.max_vms if owner.max_vms is not None else s["default_max_vms"]
        if db.query(func.count(VM.id)).filter(VM.owner_id == owner.id).scalar() >= quota:
            raise HTTPException(400, f"VM quota reached ({quota})")
    if body.cpu < tpl.min_cpu or body.ram_mb < tpl.min_ram_mb or body.disk_gb < tpl.min_disk_gb:
        raise HTTPException(400, f"{tpl.name} needs at least {tpl.min_cpu} vCPU, {tpl.min_ram_mb} MB RAM, {tpl.min_disk_gb} GB disk")
    if db.query(VM).filter(VM.owner_id == owner.id, func.lower(VM.name) == body.name.lower()).first():
        raise HTTPException(409, "You already have a VM with that name")

    vm = VM(uuid=str(uuidlib.uuid4()), name=body.name, libvirt_name=f"pending-{uuidlib.uuid4().hex[:12]}",
            owner_id=owner.id, template_id=tpl.id, os_name=tpl.name, cpu=body.cpu, ram_mb=body.ram_mb,
            disk_gb=body.disk_gb, status="creating")
    db.add(vm)
    db.flush()
    vm.libvirt_name = f"tvm-{vm.id}"
    db.commit()
    try:
        res = lv.create_vm(libvirt_name=vm.libvirt_name, cpu=vm.cpu, ram_mb=vm.ram_mb, disk_gb=vm.disk_gb,
                           image_path=tpl.image_path, iso_path=tpl.iso_path,
                           root_password=body.root_password, ssh_key=body.ssh_key)
    except lv.LibvirtError as e:
        db.delete(vm)
        db.commit()
        log_activity(db, user.id, "vm.create.failed", f"{body.name}: {e}", level="error", request=request)
        raise HTTPException(502, str(e))
    vm.uuid, vm.mac, vm.status = res["uuid"], res["mac"], "running"
    vm.started_at = datetime.now(timezone.utc)
    vm.network = "bridge" if lv.settings.libvirt_bridge else lv.settings.libvirt_network
    db.commit()
    log_activity(db, user.id, "vm.create", f"Created '{vm.name}' ({tpl.name}, {vm.cpu} vCPU, {vm.ram_mb} MB, {vm.disk_gb} GB)",
                 vm_id=vm.id, request=request)
    return serialize(vm, owner.username)


@router.get("/vms/{vm_id}")
def get_vm(vm_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    vm = get_vm_or_404(db, vm_id, user)
    sync_vm(db, vm)
    owner = db.get(User, vm.owner_id)
    d = serialize(vm, owner.username if owner else None)
    d["uuid"] = vm.uuid
    d["libvirt_name"] = vm.libvirt_name if user.role == "admin" else None
    return d


@router.get("/vms/{vm_id}/metrics")
def vm_metrics(vm_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    vm = get_vm_or_404(db, vm_id, user)
    try:
        m = lv.metrics(vm.libvirt_name)
    except lv.LibvirtError as e:
        raise HTTPException(502, str(e))
    m["uptime_seconds"] = int((datetime.now(timezone.utc) - vm.started_at).total_seconds()) if vm.started_at and m["status"] == "running" else 0
    return m


@router.get("/vms/{vm_id}/logs")
def vm_logs(vm_id: int, limit: int = 20, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    vm = get_vm_or_404(db, vm_id, user)
    rows = db.query(ActivityLog).filter(ActivityLog.vm_id == vm.id).order_by(ActivityLog.id.desc()).limit(max(1, min(limit, 100))).all()
    return [{"id": r.id, "action": r.action, "detail": r.detail, "level": r.level, "created_at": r.created_at} for r in rows]


ACTIONS = {"start", "stop", "force-stop", "reboot"}


@router.post("/vms/{vm_id}/{action}")
def vm_action(vm_id: int, action: str, request: Request, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if action not in ACTIONS:
        raise HTTPException(404, "Unknown action")
    vm = get_vm_or_404(db, vm_id, user)
    if vm.status == "creating":
        raise HTTPException(409, "VM is still being created")
    try:
        if action == "start":
            lv.start(vm.libvirt_name)
            vm.status, vm.started_at = "running", datetime.now(timezone.utc)
        elif action == "reboot":
            lv.reboot(vm.libvirt_name)
        else:
            lv.stop(vm.libvirt_name, force=action == "force-stop")
            vm.status = "stopped" if action == "force-stop" else "stopping"
            if action == "force-stop":
                vm.started_at = None
        db.commit()
    except lv.LibvirtError as e:
        log_activity(db, user.id, f"vm.{action}.failed", f"{vm.name}: {e}", vm_id=vm.id, level="error", request=request)
        raise HTTPException(502, str(e))
    log_activity(db, user.id, f"vm.{action}", f"{action} on '{vm.name}'", vm_id=vm.id, request=request)
    return serialize(vm)


@router.delete("/vms/{vm_id}", status_code=204)
def delete_vm(vm_id: int, request: Request, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    vm = get_vm_or_404(db, vm_id, user)
    name = vm.name
    try:
        lv.delete(vm.libvirt_name)
    except lv.LibvirtError as e:
        log_activity(db, user.id, "vm.delete.failed", f"{name}: {e}", vm_id=vm.id, level="error", request=request)
        raise HTTPException(502, str(e))
    db.delete(vm)
    db.commit()
    log_activity(db, user.id, "vm.delete", f"Deleted '{name}'", request=request)


@router.get("/templates")
def active_templates(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    rows = db.query(OSTemplate).filter(OSTemplate.is_active.is_(True)).order_by(OSTemplate.name).all()
    s = get_settings(db)
    return {"items": [{"id": t.id, "name": t.name, "os_family": t.os_family, "version": t.version,
                       "min_cpu": t.min_cpu, "min_ram_mb": t.min_ram_mb, "min_disk_gb": t.min_disk_gb,
                       "supports_credentials": bool(t.image_path)} for t in rows],
            "limits": {"max_cpu": s["max_cpu_per_vm"], "max_ram_mb": s["max_ram_mb_per_vm"],
                       "max_disk_gb": s["max_disk_gb_per_vm"]} if user.role != "admin" else
                      {"max_cpu": 128, "max_ram_mb": 1048576, "max_disk_gb": 10000},
            "network": "bridge" if lv.settings.libvirt_bridge else lv.settings.libvirt_network}


@router.websocket("/vms/{vm_id}/console")
async def console(ws: WebSocket, vm_id: int):
    # Authenticate manually so no DB session stays open for the lifetime of the socket.
    origin, host = ws.headers.get("origin"), ws.headers.get("host")
    if origin and host and origin.split("://", 1)[-1] != host:
        await ws.close(code=1008)
        return
    port = None
    db = SessionLocal()
    try:
        user = user_from_token(db, ws.cookies.get(COOKIE))
        vm = db.get(VM, vm_id) if user else None
        if user and vm and (vm.owner_id == user.id or user.role == "admin"):
            try:
                info = lv.runtime_info(vm.libvirt_name)
                port = info["vnc_port"] if info["status"] == "running" else None
            except lv.LibvirtError:
                port = None
            if port:
                log_activity(db, user.id, "vm.console", f"Console opened for '{vm.name}'", vm_id=vm.id)
    finally:
        db.close()
    if not port:
        await ws.close(code=1008)
        return
    sub = "binary" if "binary" in (ws.headers.get("sec-websocket-protocol") or "") else None
    try:
        reader, writer = await asyncio.open_connection("127.0.0.1", port)
    except OSError:
        await ws.close(code=1011)
        return
    await ws.accept(subprotocol=sub)

    async def to_vnc():
        try:
            while True:
                msg = await ws.receive()
                if msg.get("type") == "websocket.disconnect":
                    break
                data = msg.get("bytes") or (msg.get("text") or "").encode()
                if data:
                    writer.write(data)
                    await writer.drain()
        except Exception:
            pass

    async def to_ws():
        try:
            while True:
                data = await reader.read(65536)
                if not data:
                    break
                await ws.send_bytes(data)
        except Exception:
            pass

    tasks = [asyncio.create_task(to_vnc()), asyncio.create_task(to_ws())]
    await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
    for t in tasks:
        t.cancel()
    writer.close()
    try:
        await ws.close()
    except Exception:
        pass
