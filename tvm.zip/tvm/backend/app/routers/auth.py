from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Request, Response
from sqlalchemy import func, or_
from sqlalchemy.orm import Session

from ..config import settings
from ..db import get_db
from ..models import ActivityLog, User, VM
from ..schemas import LoginIn, ProfileUpdate, RegisterIn, UserOut
from ..security import (COOKIE, clear_login_failures, create_session, destroy_session, get_current_user,
                        hash_password, record_failed_login, throttle_login, verify_password)
from ..utils import client_ip, get_settings, log_activity

router = APIRouter(prefix="/api", tags=["auth"])


def _user_out(db: Session, u: User) -> dict:
    d = UserOut.model_validate(u).model_dump()
    d["vm_count"] = db.query(func.count(VM.id)).filter(VM.owner_id == u.id).scalar() or 0
    return d


def _set_cookie(resp: Response, token: str) -> None:
    resp.set_cookie(COOKIE, token, max_age=settings.session_hours * 3600, httponly=True,
                    secure=settings.cookie_secure, samesite="lax", path="/")


@router.get("/health")
def health():
    return {"status": "ok"}


@router.get("/public-config")
def public_config(db: Session = Depends(get_db)):
    s = get_settings(db)
    return {"panel_name": s["panel_name"], "allow_registration": s["allow_registration"],
            "refresh_interval_seconds": s["refresh_interval_seconds"]}


@router.post("/auth/login")
def login(body: LoginIn, request: Request, response: Response, db: Session = Depends(get_db)):
    ident = body.identifier.strip().lower()
    key = f"{client_ip(request)}|{ident}"
    throttle_login(key)
    user = db.query(User).filter(or_(func.lower(User.email) == ident, func.lower(User.username) == ident)).first()
    if not user or not user.is_active or not verify_password(body.password, user.password_hash):
        record_failed_login(key)
        log_activity(db, user.id if user else None, "login.failed", f"Failed login for '{ident[:64]}'", level="warning", request=request)
        raise HTTPException(401, "Invalid credentials")
    clear_login_failures(key)
    user.last_login = datetime.now(timezone.utc)
    db.commit()
    _set_cookie(response, create_session(db, user))
    log_activity(db, user.id, "login", "Signed in", request=request)
    return _user_out(db, user)


@router.post("/auth/register")
def register(body: RegisterIn, request: Request, response: Response, db: Session = Depends(get_db)):
    s = get_settings(db)
    if not s["allow_registration"]:
        raise HTTPException(403, "Registration is disabled")
    if db.query(User).filter(or_(func.lower(User.email) == body.email.lower(),
                                 func.lower(User.username) == body.username.lower())).first():
        raise HTTPException(409, "Email or username already in use")
    user = User(email=body.email.lower(), username=body.username, password_hash=hash_password(body.password), role="user")
    db.add(user)
    db.commit()
    _set_cookie(response, create_session(db, user))
    log_activity(db, user.id, "register", "Account created", request=request)
    return _user_out(db, user)


@router.post("/auth/logout", status_code=204)
def logout(request: Request, response: Response, db: Session = Depends(get_db)):
    token = request.cookies.get(COOKIE)
    if token:
        destroy_session(db, token)
    response.delete_cookie(COOKIE, path="/")


@router.get("/auth/me")
def me(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return _user_out(db, user)


@router.patch("/auth/me")
def update_me(body: ProfileUpdate, request: Request, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if body.email and body.email.lower() != user.email:
        if db.query(User).filter(func.lower(User.email) == body.email.lower(), User.id != user.id).first():
            raise HTTPException(409, "Email already in use")
        user.email = body.email.lower()
    if body.new_password:
        if not body.current_password or not verify_password(body.current_password, user.password_hash):
            raise HTTPException(400, "Current password is incorrect")
        user.password_hash = hash_password(body.new_password)
    db.commit()
    log_activity(db, user.id, "profile.update", "Profile updated", request=request)
    return _user_out(db, user)


@router.get("/activity")
def my_activity(limit: int = 10, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    rows = (db.query(ActivityLog).filter(ActivityLog.user_id == user.id)
            .order_by(ActivityLog.id.desc()).limit(max(1, min(limit, 100))).all())
    return [{"id": r.id, "action": r.action, "detail": r.detail, "level": r.level,
             "vm_id": r.vm_id, "created_at": r.created_at} for r in rows]
