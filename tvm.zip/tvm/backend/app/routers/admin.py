import os
import shutil

import psutil
from fastapi import APIRouter, Depends, HTTPException, Query, Request
from sqlalchemy import func, text
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from .. import libvirt_service as lv
from ..config import settings
from ..db import get_db
from ..models import ActivityLog, OSTemplate, User, VM
from ..schemas import AdminUserCreate, AdminUserUpdate, SettingsIn, TemplateIn, UserOut
from ..security import hash_password, require_admin
from ..utils import get_settings, log_activity, set_setting
from .vms import sync_vm

router = APIRouter(prefix="/api/admin", tags=["admin"], dependencies=[Depends(require_admin)])


@router.get("/stats")
def stats(db: Session = Depends(get_db)):
    vms = db.query(VM).all()
    for v in vms:
        sync_vm(db, v)
    return {"total_vms": len(vms),
            "running_vms": sum(v.status == "running" for v in vms),
            "stopped_vms": sum(v.status in ("stopped", "paused") for v in vms),
            "users": db.query(func.count(User.id)).scalar() or 0,
            "templates": db.query(func.count(OSTemplate.id)).scalar() or 0}


def _host() -> dict:
    disk_dir = settings.storage_dir if os.path.isdir(settings.storage_dir) else "/"
    du = shutil.disk_usage(disk_dir)
    vm = psutil.virtual_memory()
    load = os.getloadavg()
    return {"cpu_percent": psutil.cpu_percent(interval=0.2), "cpu_count": psutil.cpu_count(),
            "mem_percent": vm.percent, "mem_used_mb": int(vm.used / 1048576), "mem_total_mb": int(vm.total / 1048576),
            "disk_percent": round(du.used / du.total * 100, 1), "disk_used_gb": round(du.used / 1024 ** 3, 1),
            "disk_total_gb": round(du.total / 1024 ** 3, 1), "load": [round(x, 2) for x in load],
            "boot_time": psutil.boot_time()}


@router.get("/system-status")
def system_status(db: Session = Depends(get_db)):
    try:
        db.execute(text("SELECT 1"))
        db_ok = True
    except Exception:
        db_ok = False
    kvm_dev = os.path.exists("/dev/kvm")
    lv_ok = lv.is_available()
    versions = lv.host_versions() if lv_ok else {}
    host = _host()

    def level(p: float) -> str:
        return "critical" if p >= 90 else "warning" if p >= 75 else "ok"
    return {"kvm": {"ok": kvm_dev, "detail": "/dev/kvm available" if kvm_dev else "/dev/kvm not found (nested virtualization or KVM disabled)"},
            "libvirt": {"ok": lv_ok, "detail": f"libvirt {versions.get('libvirt', '?')} / QEMU {versions.get('qemu', '?')}" if lv_ok else "Cannot connect to libvirtd"},
            "database": {"ok": db_ok, "detail": "PostgreSQL reachable" if db_ok else "Database unreachable"},
            "host": host,
            "health": {"cpu": level(host["cpu_percent"]), "memory": level(host["mem_percent"]), "disk": level(host["disk_percent"])}}


@router.get("/monitoring")
def monitoring(db: Session = Depends(get_db)):
    net = psutil.net_io_counters()
    out = []
    for vm, uname in db.query(VM, User.username).join(User, User.id == VM.owner_id).filter(VM.status == "running").all():
        try:
            m = lv.metrics(vm.libvirt_name)
            out.append({"id": vm.id, "name": vm.name, "owner": uname, "cpu_percent": m["cpu_percent"],
                        "mem_used_mb": m["mem_used_mb"], "mem_total_mb": m["mem_total_mb"]})
        except lv.LibvirtError:
            continue
    return {"host": _host(), "net_rx_bytes": net.bytes_recv, "net_tx_bytes": net.bytes_sent,
            "vms": sorted(out, key=lambda x: -x["cpu_percent"])}


@router.get("/logs")
def logs(page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=100), level: str = "", search: str = "",
         db: Session = Depends(get_db)):
    q = db.query(ActivityLog, User.username).outerjoin(User, User.id == ActivityLog.user_id)
    if level:
        q = q.filter(ActivityLog.level == level)
    if search.strip():
        like = f"%{search.strip()}%"
        q = q.filter(ActivityLog.action.ilike(like) | ActivityLog.detail.ilike(like) | User.username.ilike(like))
    total = q.count()
    rows = q.order_by(ActivityLog.id.desc()).offset((page - 1) * page_size).limit(page_size).all()
    return {"items": [{"id": r.id, "user": u, "action": r.action, "detail": r.detail, "level": r.level,
                       "vm_id": r.vm_id, "ip": r.ip, "created_at": r.created_at} for r, u in rows],
            "total": total, "page": page, "page_size": page_size}


# ---- users ----
@router.get("/users")
def list_users(page: int = Query(1, ge=1), page_size: int = Query(10, ge=1, le=100), search: str = "",
               db: Session = Depends(get_db)):
    q = db.query(User)
    if search.strip():
        like = f"%{search.strip()}%"
        q = q.filter(User.email.ilike(like) | User.username.ilike(like))
    total = q.count()
    users = q.order_by(User.id).offset((page - 1) * page_size).limit(page_size).all()
    counts = dict(db.query(VM.owner_id, func.count(VM.id)).group_by(VM.owner_id).all())
    items = []
    for u in users:
        d = UserOut.model_validate(u).model_dump()
        d["vm_count"] = counts.get(u.id, 0)
        items.append(d)
    return {"items": items, "total": total, "page": page, "page_size": page_size}


@router.post("/users", status_code=201)
def create_user(body: AdminUserCreate, request: Request, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    from ..schemas import USERNAME_RE
    if not USERNAME_RE.match(body.username):
        raise HTTPException(400, "Username must be 3-32 chars (letters, digits, _ . -)")
    u = User(email=body.email.lower(), username=body.username, password_hash=hash_password(body.password), role=body.role)
    db.add(u)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, "Email or username already in use")
    log_activity(db, admin.id, "user.create", f"Created user {u.username} ({u.role})", request=request)
    return UserOut.model_validate(u)


@router.patch("/users/{user_id}")
def update_user(user_id: int, body: AdminUserUpdate, request: Request, admin: User = Depends(require_admin),
                db: Session = Depends(get_db)):
    u = db.get(User, user_id)
    if not u:
        raise HTTPException(404, "User not found")
    if u.id == admin.id and (body.role == "user" or body.is_active is False):
        raise HTTPException(400, "You cannot demote or deactivate your own account")
    if body.role is not None:
        u.role = body.role
    if body.is_active is not None:
        u.is_active = body.is_active
    if body.clear_max_vms:
        u.max_vms = None
    elif body.max_vms is not None:
        u.max_vms = body.max_vms
    if body.new_password:
        u.password_hash = hash_password(body.new_password)
    db.commit()
    log_activity(db, admin.id, "user.update", f"Updated user {u.username}", request=request)
    return UserOut.model_validate(u)


@router.delete("/users/{user_id}", status_code=204)
def delete_user(user_id: int, request: Request, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    u = db.get(User, user_id)
    if not u:
        raise HTTPException(404, "User not found")
    if u.id == admin.id:
        raise HTTPException(400, "You cannot delete your own account")
    for vm in db.query(VM).filter(VM.owner_id == u.id).all():
        try:
            lv.delete(vm.libvirt_name)
        except lv.LibvirtError as e:
            raise HTTPException(502, f"Could not remove VM '{vm.name}': {e}")
    name = u.username
    db.delete(u)
    db.commit()
    log_activity(db, admin.id, "user.delete", f"Deleted user {name} and their VMs", request=request)


# ---- templates ----
def _tpl(t: OSTemplate) -> dict:
    return {"id": t.id, "name": t.name, "os_family": t.os_family, "version": t.version, "image_path": t.image_path,
            "iso_path": t.iso_path, "min_cpu": t.min_cpu, "min_ram_mb": t.min_ram_mb, "min_disk_gb": t.min_disk_gb,
            "is_active": t.is_active, "file_ok": bool((t.image_path and os.path.isfile(t.image_path)) or (t.iso_path and os.path.isfile(t.iso_path)))}


def _check_paths(body: TemplateIn) -> None:
    if not body.image_path and not body.iso_path:
        raise HTTPException(400, "Provide a cloud image path or an ISO path")
    for p in (body.image_path, body.iso_path):
        if p and (not os.path.isabs(p) or ".." in p.split("/")):
            raise HTTPException(400, "Paths must be absolute and must not contain '..'")


@router.get("/templates")
def list_templates(db: Session = Depends(get_db)):
    return {"items": [_tpl(t) for t in db.query(OSTemplate).order_by(OSTemplate.name).all()]}


@router.post("/templates", status_code=201)
def create_template(body: TemplateIn, request: Request, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    _check_paths(body)
    t = OSTemplate(**body.model_dump())
    db.add(t)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, "A template with that name exists")
    log_activity(db, admin.id, "template.create", f"Created template {t.name}", request=request)
    return _tpl(t)


@router.put("/templates/{tid}")
def update_template(tid: int, body: TemplateIn, request: Request, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    t = db.get(OSTemplate, tid)
    if not t:
        raise HTTPException(404, "Template not found")
    _check_paths(body)
    for k, v in body.model_dump().items():
        setattr(t, k, v)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, "A template with that name exists")
    log_activity(db, admin.id, "template.update", f"Updated template {t.name}", request=request)
    return _tpl(t)


@router.delete("/templates/{tid}", status_code=204)
def delete_template(tid: int, request: Request, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    t = db.get(OSTemplate, tid)
    if not t:
        raise HTTPException(404, "Template not found")
    in_use = db.query(func.count(VM.id)).filter(VM.template_id == t.id).scalar()
    if in_use:
        raise HTTPException(409, f"Template is used by {in_use} VM(s); deactivate it instead (VM disks may depend on its base image)")
    name = t.name
    db.delete(t)
    db.commit()
    log_activity(db, admin.id, "template.delete", f"Deleted template {name}", request=request)


# ---- settings ----
@router.get("/settings")
def read_settings(db: Session = Depends(get_db)):
    return get_settings(db)


@router.put("/settings")
def write_settings(body: SettingsIn, request: Request, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    for k, v in body.model_dump(exclude_none=True).items():
        set_setting(db, k, v)
    db.commit()
    log_activity(db, admin.id, "settings.update", "Settings updated", request=request)
    return get_settings(db)
