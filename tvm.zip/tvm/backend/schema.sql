-- TVM Panel database schema (PostgreSQL). Idempotent.
CREATE TABLE IF NOT EXISTS users (
    id            SERIAL PRIMARY KEY,
    email         VARCHAR(255) NOT NULL UNIQUE,
    username      VARCHAR(64)  NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role          VARCHAR(16)  NOT NULL DEFAULT 'user' CHECK (role IN ('user','admin')),
    is_active     BOOLEAN      NOT NULL DEFAULT TRUE,
    max_vms       INTEGER,
    created_at    TIMESTAMPTZ  NOT NULL DEFAULT now(),
    last_login    TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS ix_users_email ON users(email);
CREATE INDEX IF NOT EXISTS ix_users_username ON users(username);

CREATE TABLE IF NOT EXISTS sessions (
    token_hash VARCHAR(64) PRIMARY KEY,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    expires_at TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_sessions_user_id ON sessions(user_id);

CREATE TABLE IF NOT EXISTS os_templates (
    id          SERIAL PRIMARY KEY,
    name        VARCHAR(128) NOT NULL UNIQUE,
    os_family   VARCHAR(32)  NOT NULL DEFAULT 'linux',
    version     VARCHAR(32)  NOT NULL DEFAULT '',
    image_path  VARCHAR(512),
    iso_path    VARCHAR(512),
    min_cpu     INTEGER NOT NULL DEFAULT 1,
    min_ram_mb  INTEGER NOT NULL DEFAULT 512,
    min_disk_gb INTEGER NOT NULL DEFAULT 10,
    is_active   BOOLEAN NOT NULL DEFAULT TRUE,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    CHECK (image_path IS NOT NULL OR iso_path IS NOT NULL)
);

CREATE TABLE IF NOT EXISTS vms (
    id           SERIAL PRIMARY KEY,
    uuid         VARCHAR(36) NOT NULL UNIQUE,
    name         VARCHAR(64) NOT NULL,
    libvirt_name VARCHAR(64) NOT NULL UNIQUE,
    owner_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    template_id  INTEGER REFERENCES os_templates(id) ON DELETE SET NULL,
    os_name      VARCHAR(128) NOT NULL,
    cpu          INTEGER NOT NULL,
    ram_mb       INTEGER NOT NULL,
    disk_gb      INTEGER NOT NULL,
    status       VARCHAR(16) NOT NULL DEFAULT 'creating',
    ip_address   VARCHAR(64),
    mac          VARCHAR(32),
    network      VARCHAR(64) NOT NULL DEFAULT 'default',
    started_at   TIMESTAMPTZ,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_vms_owner_id ON vms(owner_id);

CREATE TABLE IF NOT EXISTS activity_logs (
    id         SERIAL PRIMARY KEY,
    user_id    INTEGER REFERENCES users(id) ON DELETE SET NULL,
    vm_id      INTEGER REFERENCES vms(id) ON DELETE SET NULL,
    action     VARCHAR(64) NOT NULL,
    detail     TEXT NOT NULL DEFAULT '',
    level      VARCHAR(16) NOT NULL DEFAULT 'info',
    ip         VARCHAR(64),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_activity_user ON activity_logs(user_id);
CREATE INDEX IF NOT EXISTS ix_activity_vm ON activity_logs(vm_id);
CREATE INDEX IF NOT EXISTS ix_activity_created ON activity_logs(created_at);

CREATE TABLE IF NOT EXISTS settings (
    key   VARCHAR(64) PRIMARY KEY,
    value TEXT NOT NULL
);
