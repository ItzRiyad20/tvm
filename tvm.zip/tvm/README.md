# TVM Panel

A KVM/QEMU virtualization control panel: React + TypeScript + Tailwind frontend, FastAPI backend, libvirt for virtualization, PostgreSQL for state. Dark UI with a fixed sidebar, top bar, stat cards and a VM table; separate user and admin areas.

Everything shown in the panel comes from the database or from libvirt — there is no mock data. A fresh install is empty until you add an admin, templates and VMs.

## Contents

```
backend/    FastAPI app (app/), schema.sql, requirements.txt, .env.example
frontend/   Vite + React + TS + Tailwind source
deploy/     install.sh, nginx.conf, tvm-panel.service
scripts/    download_images.sh (Ubuntu 24.04 cloud image + template registration)
```

## Requirements

- Ubuntu 22.04 or 24.04 server, root access, outbound internet during install.
- Hardware virtualization: `/dev/kvm` must exist. On a VPS this means the provider must expose nested virtualization. Check with `ls /dev/kvm` or `egrep -c '(vmx|svm)' /proc/cpuinfo`.
- Ports 80/443 open.

## Install

```bash
unzip tvm-panel.zip && cd tvm-panel
sudo bash deploy/install.sh panel.example.com     # or omit the argument to answer on any hostname
```

The script installs QEMU/libvirt, PostgreSQL, nginx and Node 20; creates a `tvm` service user and a database with a random password; writes `/opt/tvm-panel/backend/.env` (mode 600) with a random `SECRET_KEY`; applies `schema.sql`; builds the frontend into `/var/www/tvm-panel`; and starts `tvm-panel.service` behind nginx.

Then:

```bash
# 1. first administrator
cd /opt/tvm-panel/backend && sudo -u tvm venv/bin/python -m app.cli create-admin

# 2. an OS template (downloads the official Ubuntu 24.04 cloud image, ~600 MB)
sudo bash /opt/tvm-panel/scripts/download_images.sh
```

Open `http://<server>/` and sign in. More templates: put a qcow2 cloud image or an ISO in `/var/lib/tvm/images/` (world-readable) and register its absolute path under **Admin → OS Templates**.

### HTTPS (do this before real use)

```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d panel.example.com
sudo sed -i 's/^COOKIE_SECURE=.*/COOKIE_SECURE=true/' /opt/tvm-panel/backend/.env
sudo systemctl restart tvm-panel
```

`COOKIE_SECURE=false` is the install default only so the first login works over plain HTTP. Switch it as soon as TLS is on.

### Configuration (`/opt/tvm-panel/backend/.env`)

| Variable | Meaning |
|---|---|
| `DATABASE_URL` | SQLAlchemy URL, `postgresql+psycopg://user:pass@host/db` |
| `SECRET_KEY` | Random secret (reserved for signing features; keep private) |
| `LIBVIRT_URI` | Default `qemu:///system` |
| `STORAGE_DIR` | Where VM disks are created (`/var/lib/tvm/disks`) |
| `LIBVIRT_NETWORK` | libvirt network for VM NICs (`default` = NAT 192.168.122.0/24) |
| `LIBVIRT_BRIDGE` | If set (e.g. `br0`), VMs attach to this host bridge instead — needed for public IPs |
| `SESSION_HOURS` | Session lifetime |
| `COOKIE_SECURE` | `true` when served over HTTPS |

Runtime limits (per-VM CPU/RAM/disk caps, default VM quota, registration on/off, dashboard refresh) are edited in **Admin → Settings**.

### Updating

Re-run `sudo bash deploy/install.sh` from the new unpacked project; it keeps `.env` and the database and re-applies the idempotent schema.

### Operations

```bash
journalctl -u tvm-panel -f          # API logs
systemctl restart tvm-panel
virsh list --all                    # domains are named tvm-<id>
sudo -u postgres pg_dump tvm > tvm-backup.sql
```

Back up `/var/lib/tvm/disks` as well as the database. Template backing images in `/var/lib/tvm/images` must not be moved or deleted while VMs created from them exist.

## How it works

- **VMs** are libvirt domains named `tvm-<id>`. Cloud-image templates create a qcow2 overlay on the backing image (fast clone, optional root password / SSH key through a cloud-init seed ISO). ISO templates create an empty qcow2 and boot the installer; use the web console to install.
- **Status** is read from libvirt whenever lists/details are loaded and every 10 s in the UI; if libvirt is unreachable the last known state is shown.
- **Metrics** (CPU %, memory, disk allocation, network) come from libvirt domain stats. Memory usage needs the virtio balloon stats from the guest and may read 0 until the guest reports them.
- **Console**: the API proxies a WebSocket to the VM's VNC port, which libvirt binds to 127.0.0.1 only; noVNC renders it in the browser. The socket requires a valid session, ownership/admin rights and a same-origin `Origin`.
- **Security**: Argon2 password hashes; random session tokens stored hashed server-side in an HttpOnly, SameSite=Lax cookie; every state-changing request needs an `X-TVM-CSRF` header; role checks on every endpoint; other users' VMs return 404; login throttling; all subprocess calls use argument lists (no shell); paths and credentials validated.

## API reference

All routes are under `/api`, JSON, cookie-authenticated. `U` = any signed-in user, `A` = admin only.

| Method & path | Auth | Purpose |
|---|---|---|
| `GET /health` | – | Liveness |
| `GET /public-config` | – | Panel name, registration flag, default refresh |
| `POST /auth/login` · `POST /auth/register` · `POST /auth/logout` | – / – / U | Sessions |
| `GET /auth/me` · `PATCH /auth/me` | U | Profile, email, password change |
| `GET /activity?limit=` | U | Own recent activity |
| `GET /templates` | U | Active OS templates, limits, network |
| `GET /vms/summary?scope=mine\|all` | U / A for `all` | Totals (VMs, running, stopped, RAM) |
| `GET /vms?scope&search&status&sort&order&page&page_size` | U / A for `all` | Paged VM list |
| `POST /vms` | U | Create + start (admins may set `owner_id`) |
| `GET /vms/{id}` · `DELETE /vms/{id}` | owner/A | Detail · delete (removes disk) |
| `POST /vms/{id}/start\|stop\|force-stop\|reboot` | owner/A | Power actions |
| `GET /vms/{id}/metrics` · `GET /vms/{id}/logs` | owner/A | Live metrics · VM activity |
| `WS /vms/{id}/console` | owner/A | VNC over WebSocket |
| `GET /admin/stats` · `/admin/system-status` · `/admin/monitoring` | A | Dashboard, KVM/libvirt/DB/host health, live host + VM metrics |
| `GET\|POST /admin/users`, `PATCH\|DELETE /admin/users/{id}` | A | User management |
| `GET\|POST /admin/templates`, `PUT\|DELETE /admin/templates/{id}` | A | OS templates |
| `GET\|PUT /admin/settings` | A | Platform settings |
| `GET /admin/logs?page&level&search` | A | Audit log |

## Database schema

`backend/schema.sql` — tables: `users`, `sessions`, `os_templates`, `vms`, `activity_logs`, `settings`. It is idempotent (`IF NOT EXISTS`).

## Development

```bash
# backend (needs libvirt-dev for libvirt-python, and a reachable PostgreSQL)
cd backend && python3 -m venv venv && . venv/bin/activate && pip install -r requirements.txt
cp .env.example .env   # edit
psql "$DB" -f schema.sql
uvicorn app.main:app --reload

# frontend (proxies /api to 127.0.0.1:8000)
cd frontend && npm install && npm run dev
```

## Known limitations

- **Not yet run against a live KVM host.** The code was written and syntax-checked but not exercised end-to-end here (no KVM, PostgreSQL or npm network in the build environment). Expect to fix small integration issues on first deploy — start with `journalctl -u tvm-panel` and the browser console.
- The frontend was not type-checked or built by me (`npm run build` runs `tsc` first, so any type error will surface there).
- x86_64 guests only; Windows guests need virtio drivers on the ISO.
- Single API worker by design (in-memory CPU sampling and login throttle).
- No snapshots, resize, ISO eject, firewall rules or per-VM public IP management yet.
- The visual design follows the written spec; the HKVM screenshots were not available, so proportions are an interpretation rather than a pixel match.
