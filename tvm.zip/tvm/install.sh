#!/usr/bin/env bash
# TVM Panel one-command installer. Run from the unzipped project folder:
#     sudo bash install.sh [server_name]
set -euo pipefail
cd "$(dirname "$0")"
[[ -f deploy/install.sh ]] || { echo "Run this from the unzipped tvm-panel folder (deploy/install.sh not found)."; exit 1; }
exec bash deploy/install.sh "$@"
